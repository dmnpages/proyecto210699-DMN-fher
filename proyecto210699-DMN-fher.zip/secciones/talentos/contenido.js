Dreamers.contenido.talentos = {
  "titulo": "Creadores",
  "textoBoton": "Info",
  "etiquetaSeguidores": "seguidores",
  "convocatoria": {
    "titulo": "Estamos buscando a los próximos grandes talentos. ¿Quieres formar parte de DMN?",
    "texto": "¿Quieres llevar tu contenido al siguiente nivel? Descubre si tienes lo que se necesita para unirte a la familia DMN.",
    "boton": "Quiero formar parte",
    "enlace": "unete"
  },
  "filtros": {
    "todos": "Todos",
    "tipo": "Tipo",
    "seguidores": "Seguidores",
    "cualquiera": "Cualquiera",
    "rango0": "Menos de 10K",
    "rango1": "10K - 50K",
    "rango2": "50K - 100K",
    "rango3": "Más de 100K",
    "ordenar": "Ordenar por",
    "ordenOriginal": "Orden de la agencia",
    "mas": "Más seguidores",
    "menos": "Menos seguidores",
    "az": "Nombre (A-Z)",
    "resultado": "Mostrando {n} de {total}",
    "vacio": "No hay creadores de contenido con esos filtros.",
    "limpiar": "Ver todos"
  }
};
