"""Revisión de ortografía para el editor.

Usa LanguageTool (https://languagetool.org), un corrector de código abierto, a través de su servicio público gratuito.
Los textos que se revisan salen de tu computadora hacia ese servicio. Para no enviar nada fuera puedes instalar tu propio
LanguageTool y poner antes de ejecutar el servidor:  DREAMERS_LT_URL=http://localhost:8010/v2/check
El servicio público limita las consultas (unas 20 por minuto), por eso se envían en lotes.
"""
import json, os, re, time, urllib.parse, urllib.request
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
LT_URL = os.environ.get("DREAMERS_LT_URL", "https://api.languagetool.org/v2/check")
ARCHIVO_IGNORAR = RAIZ / "config" / "ortografia.json"
LOTE = 12000

# Palabras que no son errores aunque el corrector no las conozca (marcas, redes, términos de streaming).
PALABRAS_PROPIAS = {
    "streaming", "streamer", "streamers", "stream", "streams", "gaming", "gamer", "gamers", "cosplay", "cosplayer", "cosplayers",
    "tiktok", "twitch", "youtube", "instagram", "facebook", "kick", "discord", "whatsapp", "lifestyle", "geek", "news", "host",
    "podcast", "online", "live", "lives", "reels", "reel", "dreamers", "media", "nicaragua", "followers", "influencer", "influencers",
    "youtuber", "youtubers", "tiktoker", "tiktokers", "gameplay", "gameplays", "blog", "marketing", "comedy", "music", "tech", "dancing",
    "fandom", "setup", "hashtag", "hashtags", "feed", "ads", "ad", "contenido", "k", "m", "us", "about",
}


def palabras_ignoradas():
    extra = []
    try:
        extra = json.loads(ARCHIVO_IGNORAR.read_text(encoding="utf-8")).get("ignorar", [])
    except Exception:
        pass
    return PALABRAS_PROPIAS | {str(x).lower() for x in extra}


def agregar_ignorada(palabra):
    palabra = str(palabra).strip()
    if not palabra or len(palabra) > 60:
        raise ValueError("Palabra no válida.")
    datos = {"ignorar": []}
    try:
        datos = json.loads(ARCHIVO_IGNORAR.read_text(encoding="utf-8"))
    except Exception:
        pass
    lista = datos.setdefault("ignorar", [])
    if palabra.lower() not in [x.lower() for x in lista]:
        lista.append(palabra)
    ARCHIVO_IGNORAR.parent.mkdir(exist_ok=True)
    ARCHIVO_IGNORAR.write_text(json.dumps(datos, ensure_ascii=False, indent=2), encoding="utf-8")


def consultar(texto):
    """Pide a LanguageTool las coincidencias de un texto. Devuelve la lista 'matches' de su respuesta."""
    cuerpo = urllib.parse.urlencode({
        "text": texto, "language": "es", "enabledOnly": "false",
        "disabledCategories": "STYLE,TYPOGRAPHY,REDUNDANCY,PLAIN_ENGLISH,SEMANTICS,COLLOQUIALISMS,WIKIPEDIA",
        "disabledRules": "UPPERCASE_SENTENCE_START,WHITESPACE_RULE,COMMA_PARENTHESIS_WHITESPACE,DOUBLE_PUNCTUATION,MORFOLOGIK_RULE_ES_UPPERCASE",
    }).encode("utf-8")
    pedido = urllib.request.Request(LT_URL, data=cuerpo, headers={"Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json",
                                                                  "User-Agent": "dreamers-editor"})
    with urllib.request.urlopen(pedido, timeout=25) as r:
        return json.loads(r.read().decode("utf-8")).get("matches", [])


def _util(m, texto, ignoradas):
    """Convierte una coincidencia al formato del editor, o None si no hay que mostrarla."""
    inicio, largo = m.get("offset", 0), m.get("length", 0)
    reemplazos = [r.get("value") for r in (m.get("replacements") or []) if r.get("value")][:4]
    palabra = texto[inicio:inicio + largo]
    reemplazos = [r for r in reemplazos if r != palabra]
    if not reemplazos or largo <= 0:
        return None
    fichas = re.findall(r"[\wáéíóúüñÁÉÍÓÚÜÑ']+", palabra)
    if fichas and all(f.lower() in ignoradas for f in fichas):
        return None
    if re.search(r"\d|@|https?:", palabra):
        return None
    regla = (m.get("rule") or {})
    return {"inicio": inicio, "largo": largo, "palabra": palabra, "mensaje": m.get("shortMessage") or m.get("message") or "",
            "reemplazos": reemplazos, "ortografia": (regla.get("issueType") == "misspelling") or "MORFOLOGIK" in str(regla.get("id", ""))}


def revisar(textos):
    """Revisa una lista de textos. Devuelve, por texto, la lista de problemas encontrados."""
    ignoradas = palabras_ignoradas()
    textos = [str(t) for t in textos]
    resultado = [[] for _ in textos]
    lote, indices, largo, pedidos = [], [], 0, 0

    def enviar():
        nonlocal lote, indices, largo, pedidos
        if not lote:
            return
        if pedidos:
            time.sleep(3.2)
        pedidos += 1
        sep, pos, inicios = "\n\n", 0, []
        for t in lote:
            inicios.append(pos)
            pos += len(t) + len(sep)
        for m in consultar(sep.join(lote)):
            off = m.get("offset", 0)
            k = max(i for i, s in enumerate(inicios) if s <= off)
            if off + m.get("length", 0) > inicios[k] + len(lote[k]):
                continue
            local = dict(m, offset=off - inicios[k])
            util = _util(local, lote[k], ignoradas)
            if util:
                resultado[indices[k]].append(util)
        lote, indices, largo = [], [], 0

    for i, t in enumerate(textos):
        if len(t.strip()) < 3:
            continue
        if lote and largo + len(t) > LOTE:
            enviar()
        lote.append(t); indices.append(i); largo += len(t) + 2
    enviar()
    return resultado
