from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import base64, hashlib, json, mimetypes, os, shutil, unicodedata, urllib.parse
import imagenes as imagenes_mod
import lector_seguidores, lector_navegador, lector_contenido, lector_fotos, ortografia, seo, subprocess, sys
import hmac, re, secrets, time

RAIZ = Path(__file__).resolve().parent


PAGINA_TALENTO = """<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','GTM-5T8WS3B8');</script>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','GTM-NQVSWM64');</script>
<!-- End Google Tag Manager -->
<title>Creador de contenido | Dreamers Media Nicaragua</title>
<link rel="icon" href="../../assets/img/favicon.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Audiowide&family=Noto+Sans:wght@400;500;700&display=swap" media="print" onload="this.media='all'">
<noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Audiowide&family=Noto+Sans:wght@400;500;700&display=swap"></noscript>
<link rel="stylesheet" href="../../assets/css/base.css?v=24">
<link rel="stylesheet" href="../../secciones/encabezado/estilos.css?v=24">
<link rel="stylesheet" href="../../secciones/perfil/estilos.css?v=24">
<link rel="stylesheet" href="../../secciones/pie/estilos.css?v=24">
<link rel="stylesheet" href="../../config/tema.css?v=24">
</head>
<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5T8WS3B8" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NQVSWM64" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<div data-pagina="perfil">
<div data-seccion="encabezado"></div>
<main><div data-seccion="perfil"></div></main>
<div data-seccion="pie"></div>
</div>
<script defer src="../../assets/js/nucleo.js?v=24"></script>
<script defer src="../../secciones/encabezado/contenido.js?v=24"></script>
<script defer src="../../secciones/perfil/contenido.js?v=24"></script>
<script defer src="../../secciones/pie/contenido.js?v=24"></script>
<script defer src="../../secciones/encabezado/seccion.js?v=24"></script>
<script defer src="../../secciones/perfil/seccion.js?v=24"></script>
<script defer src="../../secciones/pie/seccion.js?v=24"></script>
<script defer src="../lista.js?v=24"></script>
<script defer src="../../assets/js/arranque.js?v=24"></script>
</body>
</html>
"""


def escribir_pagina_talento(carpeta_talento):
    """Cada talento tiene su propia carpeta con index.html: así la URL es /creadores/<nombre>
    (sin .html y sin #) y funciona en GitHub Pages y en cualquier hosting estático."""
    (Path(carpeta_talento) / "index.html").write_text(PAGINA_TALENTO, encoding="utf-8")


def slug(texto):
    """Nombre de carpeta seguro para la URL: minúsculas, sin tildes ni espacios (usa guiones)."""
    texto = unicodedata.normalize("NFKD", str(texto)).encode("ascii", "ignore").decode("ascii").lower()
    return "".join(c if c.isalnum() or c in "-_" else "-" for c in texto).strip("-_")


def allowed_section_name(nombre):
    return bool(nombre) and all(c.isalnum() or c in "-_" for c in nombre)


def js_literal(value, indent=0):
    if isinstance(value, dict):
        if not value:
            return "{}"
        spaces = " " * indent
        child = " " * (indent + 2)
        partes = []
        for clave, val in value.items():
            nombre = json.dumps(str(clave), ensure_ascii=False)
            partes.append(child + nombre + ": " + js_literal(val, indent + 2))
        return "{\n" + ",\n".join(partes) + "\n" + spaces + "}"
    if isinstance(value, list):
        if not value:
            return "[]"
        espacios = " " * (indent + 2)
        return "[\n" + ",\n".join(espacios + js_literal(v, indent + 2) for v in value) + "\n" + " " * indent + "]"
    return json.dumps(value, ensure_ascii=False)

def leer_seguidores(redes):
    """Con sesión guardada lee con el navegador propio; lo que falle (o sin sesión) se intenta sin iniciar sesión."""
    resultados, modo = [], "sin sesión"
    if lector_navegador.disponible() and lector_navegador.hay_sesion():
        try:
            proc = subprocess.run([sys.executable, str(RAIZ / "lector_navegador.py"), "leer"], input=json.dumps(redes),
                                  capture_output=True, text=True, timeout=900, cwd=str(RAIZ))
            if proc.returncode == 0 and proc.stdout.strip():
                resultados, modo = json.loads(proc.stdout.strip().splitlines()[-1]), "con tu sesión"
        except Exception:
            resultados = []
    hechos = {str(r.get("id")) for r in resultados if r.get("ok")}
    pendientes = [r for r in redes if str(r.get("id")) not in hechos]
    if pendientes:
        resultados = [r for r in resultados if r.get("ok")] + lector_seguidores.leer_varios(pendientes)
    return {"ok": True, "modo": modo, "resultados": resultados}


def leer_auto(destino):
    """Lee creadores/<carpeta>/auto.js y devuelve su contenido como diccionario ({} si no existe)."""
    try:
        t = (destino / "auto.js").read_text(encoding="utf-8")
        return json.loads(t[t.index("{"):t.rindex("}") + 1])
    except Exception:
        return {}


def fijar_contenido(carpeta, fijados):
    """Guarda los videos que el usuario eligió a mano: van primero en el carrusel y se conservan al actualizar."""
    destino = RAIZ / "creadores" / str(carpeta)
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]*", str(carpeta)) or not destino.is_dir():
        raise ValueError("Creador no válido.")
    previo = leer_auto(destino)
    fijados = [u for u in fijados if isinstance(u, str) and re.match(r"https?://", u)][:lector_contenido.ELEGIDOS]
    resto = [u for u in (previo.get("elegidos", []) + previo.get("reserva", [])) if u not in fijados]
    todo = fijados + resto
    datos = {"elegidos": todo[:lector_contenido.ELEGIDOS], "reserva": todo[lector_contenido.ELEGIDOS:lector_contenido.ELEGIDOS + lector_contenido.RESERVA],
             "fijados": fijados, "candidatas": previo.get("candidatas", [])}
    (destino / "auto.js").write_text(lector_contenido.texto_auto_js(str(carpeta), datos), encoding="utf-8")
    return {"ok": True, "elegidos": len(datos["elegidos"])}


def actualizar_contenido(creadores):
    """Para cada creador elige el contenido del carrusel y lo guarda en creadores/<carpeta>/auto.js."""
    cosechadas, modo = {}, "sin sesión"
    enlaces = sorted({str(r.get("enlace", "")) for c in creadores for r in c.get("redes", []) if r.get("enlace")})
    if enlaces and lector_navegador.disponible() and lector_navegador.hay_sesion():
        try:
            proc = subprocess.run([sys.executable, str(RAIZ / "lector_navegador.py"), "cosechar"], input=json.dumps(enlaces),
                                  capture_output=True, text=True, timeout=900, cwd=str(RAIZ))
            if proc.returncode == 0 and proc.stdout.strip():
                cosechadas, modo = json.loads(proc.stdout.strip().splitlines()[-1]), "con tu sesión"
        except Exception:
            cosechadas = {}
    salida = []
    for c in creadores:
        carpeta = str(c.get("carpeta", ""))
        destino = RAIZ / "creadores" / carpeta
        if not re.fullmatch(r"[a-z0-9][a-z0-9-]*", carpeta) or not destino.is_dir():
            continue
        previo = leer_auto(destino)
        datos = lector_contenido.descubrir(c.get("redes", []), cosechadas, previo.get("fijados"))
        (destino / "auto.js").write_text(lector_contenido.texto_auto_js(carpeta, datos), encoding="utf-8")
        salida.append({"carpeta": carpeta, "elegidos": len(datos["elegidos"]), "reserva": len(datos["reserva"]), "resumen": datos["resumen"]})
    return {"ok": True, "modo": modo, "creadores": salida}


def traer_fotos(creadores):
    """Para cada creador sin foto, descarga la foto de perfil de sus redes a creadores/<carpeta>/foto-redes.<ext>."""
    metas, modo = {}, "sin sesión"
    enlaces = sorted({str(r.get("enlace", "")) for c in creadores for r in c.get("redes", []) if r.get("enlace")})
    if enlaces and lector_navegador.disponible() and lector_navegador.hay_sesion():
        try:
            proc = subprocess.run([sys.executable, str(RAIZ / "lector_navegador.py"), "metas"], input=json.dumps(enlaces),
                                  capture_output=True, text=True, timeout=600, cwd=str(RAIZ))
            if proc.returncode == 0 and proc.stdout.strip():
                metas, modo = json.loads(proc.stdout.strip().splitlines()[-1]), "con tu sesión"
        except Exception:
            metas = {}
    salida = []
    for c in creadores:
        carpeta = str(c.get("carpeta", ""))
        destino = RAIZ / "creadores" / carpeta
        if not re.fullmatch(r"[a-z0-9][a-z0-9-]*", carpeta) or not destino.is_dir():
            continue
        hallada = lector_fotos.buscar(c.get("redes", []), metas)
        if not hallada:
            salida.append({"carpeta": carpeta, "ok": False})
            continue
        datos, ext, red = hallada
        for vieja in destino.glob("foto-redes.*"):
            vieja.unlink()
        (destino / ("foto-redes." + ext)).write_bytes(datos)
        salida.append({"carpeta": carpeta, "ok": True, "archivo": "foto-redes." + ext, "red": red})
    return {"ok": True, "modo": modo, "creadores": salida}

# ---- Restablecer la contraseña del panel: el código solo aparece en la terminal de quien ejecuta este servidor.
RECUPERACION = {"codigo": None, "vence": 0, "intentos": 0, "ultimo_pedido": 0}


def pedir_codigo_recuperacion():
    ahora = time.time()
    if ahora - RECUPERACION["ultimo_pedido"] < 20:
        return {"ok": False, "error": "Espera unos segundos antes de pedir otro código."}
    RECUPERACION.update(codigo="%08d" % secrets.randbelow(10 ** 8), vence=ahora + 600, intentos=0, ultimo_pedido=ahora)
    linea = "  CÓDIGO PARA RESTABLECER LA CONTRASEÑA DEL PANEL:  %s  (vale 10 minutos)  " % RECUPERACION["codigo"]
    print("\n" + "=" * len(linea) + "\n" + linea + "\n" + "=" * len(linea) + "\n", flush=True)
    return {"ok": True}


def confirmar_codigo_recuperacion(escrito):
    if not RECUPERACION["codigo"] or time.time() > RECUPERACION["vence"]:
        return {"ok": False, "error": "El código venció. Pide uno nuevo."}
    RECUPERACION["intentos"] += 1
    if RECUPERACION["intentos"] > 5:
        RECUPERACION["codigo"] = None
        return {"ok": False, "error": "Demasiados intentos. Pide un código nuevo."}
    if hmac.compare_digest(str(escrito).strip().replace(" ", ""), RECUPERACION["codigo"]):
        RECUPERACION["codigo"] = None
        return {"ok": True}
    return {"ok": False, "error": "Código incorrecto."}

def guardar_tema(datos):
    """Guarda config/tema.css, config/tema.json y las imágenes de fondo (config/fondos/)."""
    css = str(datos.get("css", ""))
    tema = datos.get("tema", {})
    if len(css) > 200000 or not isinstance(tema, dict):
        raise ValueError("Datos de apariencia no válidos.")
    carpeta = RAIZ / "config"
    fondos = carpeta / "fondos"
    carpeta.mkdir(exist_ok=True)
    for clave, data in (datos.get("imagenes") or {}).items():
        coincide = re.match(r"data:image/(png|jpeg|webp|gif|svg\+xml);base64,(.+)$", str(data), re.S)
        if not re.fullmatch(r"[A-Za-z]{2,20}", str(clave)) or not coincide:
            continue
        crudo = base64.b64decode(coincide.group(2))
        if len(crudo) > 10 * 1024 * 1024:
            raise ValueError("Una imagen de fondo pesa más de 10 MB.")
        extension = {"jpeg": "jpg", "svg+xml": "svg"}.get(coincide.group(1), coincide.group(1))
        fondos.mkdir(exist_ok=True)
        for viejo in fondos.glob("fondo-%s.*" % clave):
            viejo.unlink()
        (fondos / ("fondo-%s.%s" % (clave, extension))).write_bytes(crudo)
    usadas = {os.path.basename(str(f.get("imagen", ""))) for f in (tema.get("fondos") or {}).values() if isinstance(f, dict) and f.get("modo") == "imagen"}
    if fondos.exists():
        for archivo in fondos.iterdir():
            if archivo.name.startswith("fondo-") and archivo.name not in usadas:
                archivo.unlink()
    (carpeta / "tema.json").write_text(json.dumps(tema, ensure_ascii=False, indent=2), encoding="utf-8")
    (carpeta / "tema.css").write_text(css, encoding="utf-8")
    return {"ok": True}

class EditorHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        ruta = urllib.parse.urlparse(self.path).path
        if ruta == "/api/talentos":
            talentos = []
            lista = RAIZ / "creadores" / "lista.js"
            if lista.exists():
                texto = lista.read_text(encoding="utf-8")
                inicio = texto.find("[")
                fin = texto.rfind("]")
                if inicio >= 0 and fin >= inicio:
                    carpetas = json.loads(texto[inicio:fin + 1])
                    for carpeta in carpetas:
                        archivo = RAIZ / "creadores" / carpeta / "datos.js"
                        if not archivo.exists():
                            continue
                        contenido = archivo.read_text(encoding="utf-8")
                        inicio_datos = contenido.find("(")
                        if inicio_datos < 0:
                            continue
                        contenido_datos = contenido[inicio_datos + 1:].strip()
                        if contenido_datos.endswith(";"): contenido_datos = contenido_datos[:-1].rstrip()
                        if contenido_datos.endswith(")"): contenido_datos = contenido_datos[:-1].rstrip()
                        dato = json.loads(contenido_datos)
                        dato["carpeta"] = carpeta
                        talentos.append(dato)
            respuesta_json = json.dumps({"talentos": talentos}, ensure_ascii=False)
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            self.wfile.write(respuesta_json.encode("utf-8"))
            return
        if ruta == "/favicon.ico":
            favicon = (RAIZ / "assets" / "img" / "favicon.svg").read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "image/svg+xml")
            self.send_header("Content-Length", str(len(favicon)))
            self.end_headers()
            self.wfile.write(favicon)
            return
        super().do_GET()

    def do_POST(self):
        ruta_post = urllib.parse.urlparse(self.path).path
        if ruta_post in ("/api/ortografia", "/api/ortografia/ignorar"):
            try:
                longitud = int(self.headers.get("Content-Length", "0"))
                datos_o = json.loads(self.rfile.read(longitud).decode("utf-8"))
                if ruta_post == "/api/ortografia":
                    resultado = {"ok": True, "problemas": ortografia.revisar(datos_o.get("textos", [])[:600])}
                else:
                    ortografia.agregar_ignorada(datos_o.get("palabra", ""))
                    resultado = {"ok": True}
            except Exception as error:
                resultado = {"ok": False, "error": "No se pudo consultar el corrector (¿hay internet?): " + str(error)}
            cuerpo = json.dumps(resultado, ensure_ascii=False).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(cuerpo)))
            self.end_headers()
            self.wfile.write(cuerpo)
            return
        if ruta_post == "/api/tema":
            try:
                longitud = int(self.headers.get("Content-Length", "0"))
                resultado = guardar_tema(json.loads(self.rfile.read(longitud).decode("utf-8")))
            except Exception as error:
                resultado = {"ok": False, "error": str(error)}
            cuerpo = json.dumps(resultado, ensure_ascii=False).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(cuerpo)))
            self.end_headers()
            self.wfile.write(cuerpo)
            return
        if ruta_post in ("/api/recuperar/pedir", "/api/recuperar/confirmar"):
            try:
                longitud = int(self.headers.get("Content-Length", "0"))
                pedido = json.loads(self.rfile.read(longitud).decode("utf-8") or "{}") if longitud else {}
                if ruta_post.endswith("pedir"):
                    resultado = pedir_codigo_recuperacion()
                else:
                    resultado = confirmar_codigo_recuperacion(pedido.get("codigo", ""))
            except Exception as error:
                resultado = {"ok": False, "error": str(error)}
            cuerpo = json.dumps(resultado, ensure_ascii=False).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(cuerpo)))
            self.end_headers()
            self.wfile.write(cuerpo)
            return
        if ruta_post == "/api/conectar-redes":
            if not lector_navegador.disponible():
                resultado, codigo = {"ok": False, "error": lector_navegador.AVISO}, 200
            else:
                subprocess.Popen([sys.executable, str(RAIZ / "lector_navegador.py"), "conectar"], cwd=str(RAIZ))
                resultado, codigo = {"ok": True}, 200
            cuerpo = json.dumps(resultado, ensure_ascii=False).encode("utf-8")
            self.send_response(codigo)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(cuerpo)))
            self.end_headers()
            self.wfile.write(cuerpo)
            return
        if ruta_post in ("/api/seo/leer", "/api/seo/guardar"):
            try:
                longitud = int(self.headers.get("Content-Length", "0"))
                pedido = json.loads(self.rfile.read(longitud).decode("utf-8") or "{}")
                if ruta_post.endswith("guardar"):
                    seo.guardar_config(pedido)
                    resumen = seo.sincronizar()
                else:
                    resumen = None
                resultado = {"ok": True, "config": seo.config(), "dominio": seo.dominio(), "resumen": resumen}
            except Exception as error:
                resultado = {"ok": False, "error": str(error)}
            cuerpo = json.dumps(resultado, ensure_ascii=False).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(cuerpo)))
            self.end_headers()
            self.wfile.write(cuerpo)
            return
        if ruta_post == "/api/fotos":
            try:
                longitud = int(self.headers.get("Content-Length", "0"))
                pedido = json.loads(self.rfile.read(longitud).decode("utf-8"))
                resultado, codigo = traer_fotos(pedido.get("creadores", [])), 200
            except Exception as error:
                resultado, codigo = {"ok": False, "error": str(error)}, 500
            cuerpo = json.dumps(resultado, ensure_ascii=False).encode("utf-8")
            self.send_response(codigo)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(cuerpo)))
            self.end_headers()
            self.wfile.write(cuerpo)
            return
        if ruta_post == "/api/contenido/fijar":
            try:
                longitud = int(self.headers.get("Content-Length", "0"))
                pedido = json.loads(self.rfile.read(longitud).decode("utf-8"))
                resultado, codigo = fijar_contenido(pedido.get("carpeta", ""), pedido.get("fijados", [])), 200
            except Exception as error:
                resultado, codigo = {"ok": False, "error": str(error)}, 500
            cuerpo = json.dumps(resultado, ensure_ascii=False).encode("utf-8")
            self.send_response(codigo)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(cuerpo)))
            self.end_headers()
            self.wfile.write(cuerpo)
            return
        if ruta_post == "/api/contenido":
            try:
                longitud = int(self.headers.get("Content-Length", "0"))
                pedido = json.loads(self.rfile.read(longitud).decode("utf-8"))
                resultado, codigo = actualizar_contenido(pedido.get("creadores", [])), 200
            except Exception as error:
                resultado, codigo = {"ok": False, "error": str(error)}, 500
            cuerpo = json.dumps(resultado, ensure_ascii=False).encode("utf-8")
            self.send_response(codigo)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(cuerpo)))
            self.end_headers()
            self.wfile.write(cuerpo)
            return
        if ruta_post == "/api/seguidores":
            try:
                longitud = int(self.headers.get("Content-Length", "0"))
                pedido = json.loads(self.rfile.read(longitud).decode("utf-8"))
                resultado, codigo = leer_seguidores(pedido.get("redes", [])), 200
            except Exception as error:
                resultado, codigo = {"ok": False, "error": str(error)}, 500
            cuerpo = json.dumps(resultado, ensure_ascii=False).encode("utf-8")
            self.send_response(codigo)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(cuerpo)))
            self.end_headers()
            self.wfile.write(cuerpo)
            return
        if ruta_post != "/api/guardar":
            self.send_error(404)
            return
        try:
            longitud = int(self.headers.get("Content-Length", "0"))
            datos = json.loads(self.rfile.read(longitud).decode("utf-8"))
            talentos = datos["talentos"]
            contenidos = datos.get("contenido", {})
            imagenes = datos.get("imagenes", {})
            carpetas_validas = []

            for index, talento in enumerate(talentos):
                if not isinstance(talento, dict):
                    continue
                origen = slug(talento.pop("_origen", "") or "")
                base = slug(talento.get("carpeta") or "") or slug(talento.get("nombre") or "") or "talento-" + str(index + 1)
                carpeta, n = base, 2
                while carpeta in carpetas_validas:
                    carpeta = base + "-" + str(n)
                    n += 1
                talento["carpeta"] = carpeta
                destino = RAIZ / "creadores" / carpeta
                destino.mkdir(parents=True, exist_ok=True)

                # Si le cambiaron el nombre a la carpeta, se llevan sus fotos a la carpeta nueva.
                if origen and origen != carpeta and (RAIZ / "creadores" / origen).is_dir():
                    for archivo in (RAIZ / "creadores" / origen).iterdir():
                        if archivo.is_file() and archivo.name not in ("datos.js", "index.html") and not (destino / archivo.name).exists():
                            shutil.copy2(archivo, destino / archivo.name)

                foto = talento.get("foto", "")
                if isinstance(foto, str) and re.match(r"data:(image/|application/octet-stream)", foto) and "," in foto:
                    cabecera, contenido = foto.split(",", 1)
                    crudo = base64.b64decode(contenido)
                    crudo, extension = imagenes_mod.optimizar(crudo)   # ligera: máx. 1000 px, WebP
                    if extension:
                        nombre_foto = "foto-admin." + extension
                        for vieja in destino.glob("foto-admin.*"):
                            vieja.unlink()
                        (destino / nombre_foto).write_bytes(crudo)
                        talento["foto"] = nombre_foto

                # Sin huecos ni valores vacíos en las listas de redes.
                talento["redes"] = [r for r in (talento.get("redes") or []) if isinstance(r, dict) and (r.get("plataforma") or r.get("enlace") or r.get("usuario"))]

                datos_talento = dict(talento)
                datos_talento.pop("carpeta", None)
                datos_talento.pop("email", None)
                if not str(datos_talento.get("correo", "")).strip():
                    datos_talento.pop("correo", None)
                (destino / "datos.js").write_text(
                    "Dreamers.talento(" + js_literal(datos_talento) + ");\n",
                    encoding="utf-8"
                )
                escribir_pagina_talento(destino)
                carpetas_validas.append(carpeta)

            talentos_raiz = RAIZ / "creadores"
            for directorio in talentos_raiz.iterdir():
                if directorio.is_dir() and directorio.name not in carpetas_validas:
                    if (directorio / "datos.js").exists():
                        shutil.rmtree(directorio)

            (talentos_raiz / "lista.js").write_text(
                "Dreamers.listaTalentos = " + js_literal(carpetas_validas, 0) + ";\n",
                encoding="utf-8"
            )

            try:
                imagenes_mod.escribir_paquete()
            except Exception as error_paquete:
                print("Aviso: no se pudo crear el paquete de creadores:", error_paquete)
            imagenes_guardadas = {}
            for ruta_campo, imagen in imagenes.items():
                if not isinstance(imagen, str) or not re.match(r"data:(image/|application/octet-stream)", imagen) or "," not in imagen:
                    continue
                partes = ruta_campo.split(".", 1)
                if len(partes) != 2:
                    continue
                nombre_seccion, campo = partes
                if not allowed_section_name(nombre_seccion):
                    continue
                carpeta_seccion = RAIZ / "secciones" / nombre_seccion
                if not carpeta_seccion.exists():
                    continue
                cabecera, contenido_imagen = imagen.split(",", 1)
                crudo_imagen, extension = imagenes_mod.optimizar(base64.b64decode(contenido_imagen), 1400)
                if not extension:
                    continue
                contenido_imagen = base64.b64encode(crudo_imagen).decode("ascii")
                codigo = hashlib.sha1(ruta_campo.encode("utf-8")).hexdigest()[:10]
                nombre_archivo = "imagen-" + codigo + "." + extension
                carpeta_destino = carpeta_seccion / "logos" if campo.startswith("logos.") else carpeta_seccion
                carpeta_destino.mkdir(parents=True, exist_ok=True)
                (carpeta_destino / nombre_archivo).write_bytes(base64.b64decode(contenido_imagen))
                if nombre_seccion in contenidos:
                    contenido = contenidos[nombre_seccion]
                    destino_objeto = contenido
                    for parte in campo.split(".")[:-1]:
                        if isinstance(destino_objeto, dict):
                            destino_objeto = destino_objeto.get(parte)
                        elif isinstance(destino_objeto, list) and parte.isdigit():
                            destino_objeto = destino_objeto[int(parte)]
                        else:
                            destino_objeto = None
                        if destino_objeto is None:
                            break
                    ultimo = campo.split(".")[-1]
                    if isinstance(destino_objeto, dict):
                        destino_objeto[ultimo] = nombre_archivo
                    elif isinstance(destino_objeto, list) and ultimo.isdigit():
                        destino_objeto[int(ultimo)] = nombre_archivo
                imagenes_guardadas[ruta_campo] = nombre_archivo

            for nombre, contenido in contenidos.items():
                destino = RAIZ / "secciones" / nombre / "contenido.js"
                if destino.parent.exists():
                    destino.write_text(
                        "Dreamers.contenido." + nombre + " = " + js_literal(contenido, 0) + ";\n",
                        encoding="utf-8"
                    )

            try:
                seo.sincronizar()
            except Exception as error_seo:
                print("Aviso: no se pudo actualizar el SEO:", error_seo)

            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            self.wfile.write(json.dumps({"ok": True, "carpetas": carpetas_validas, "imagenes": imagenes_guardadas}, ensure_ascii=False).encode("utf-8"))
        except Exception as error:
            self.send_response(500)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            self.wfile.write(json.dumps({"ok": False, "error": str(error)}, ensure_ascii=False).encode("utf-8"))

    def send_error(self, code, message=None, explain=None):
        # Igual que en GitHub Pages: una dirección que no existe muestra 404.html
        pagina = RAIZ / "404.html"
        if code == 404 and pagina.exists() and self.command == "GET":
            cuerpo = pagina.read_bytes()
            self.send_response(404)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(cuerpo)))
            self.end_headers()
            self.wfile.write(cuerpo)
            return
        super().send_error(code, message, explain)

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()


if __name__ == "__main__":
    mimetypes.add_type("application/javascript", ".js")
    puerto = int(os.environ.get("PORT", "8000"))
    print("Dreamers Media Nicaragua disponible en http://localhost:%d  (editor: /admin/)" % puerto)
    ThreadingHTTPServer(("127.0.0.1", puerto), lambda *args, **kwargs: EditorHandler(*args, directory=str(RAIZ), **kwargs)).serve_forever()
