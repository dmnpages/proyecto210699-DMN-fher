# Dreamers Media Nicaragua: guía rápida para editar el sitio

No necesitas instalar nada. Todo son archivos de texto que puedes abrir con el Bloc de notas, o mejor con un editor gratis como VS Code. Para ver el sitio, haz doble clic en `index.html`.

## Direcciones (URLs) del sitio

Todas son limpias: sin `.html`, sin `index` y sin `#`.

| Dirección | Página |
|---|---|
| `/` | Inicio |
| `/talentos` | Todos los creadores de contenido |
| `/creadores/kimera` | Perfil de un creador de contenido (el nombre es el de su carpeta en `creadores/`) |
| `/nosotros` | Sobre nosotros |
| `/contacto` | Contacto |

Cada página es una carpeta con su `index.html` (por eso no se ve `.html`). Esto funciona en GitHub Pages y en cualquier hosting estático. **Ya no se abre con doble clic en `index.html`**: usa el servidor local (`python servidor_editor.py`, abajo) para ver el sitio mientras lo editas.

## Cómo está organizado

```
dreamers-nicaragua/
├── index.html            Inicio (/)
├── 404.html              Página de error
├── creadores/index.html   Lista de creadores de contenido (/talentos)
├── nosotros/index.html   Sobre nosotros (/nosotros)
├── contacto/index.html   Contacto (/contacto)
├── assets/
│   ├── css/base.css      COLORES Y FUENTES de todo el sitio (arriba del archivo)
│   ├── js/               Código general (no hace falta tocarlo)
│   └── img/              Imagen "sin foto"
├── secciones/            Una carpeta por cada apartado de la página
│   ├── encabezado/       Menú de arriba
│   ├── portada/          Lo primero que se ve
│   ├── creadores/         La cuadrícula de tarjetas
│   ├── nosotros/         Sobre nosotros (con su imagen)
│   ├── clientes/         Carrusel de marcas (con la carpeta logos/)
│   ├── contacto/         Formulario
│   ├── pie/              Pie de página
│   └── perfil/           Plantilla de la página de cada creador de contenido
├── admin/                Editor visual (solo local, NO se publica)
├── servidor_editor.py    Servidor local para ver el sitio y guardar desde el editor
└── creadores/             UNA CARPETA POR CADA CREADOR DE CONTENIDO (se sigue llamando creadores/)
    ├── lista.js          Quiénes salen y en qué orden
    ├── kimera/           datos.js + foto + index.html
    └── ...
```

Dentro de cada carpeta de `secciones/` hay siempre tres archivos:

| Archivo | Para qué sirve | ¿Lo edito? |
|---|---|---|
| `contenido.js` | Los textos de ese apartado | Sí, aquí |
| `estilos.css` | Cómo se ve (tamaños, fondos) | Solo si quieres cambiar el diseño |
| `seccion.js` | El código que arma el apartado | No |

## Temporadas (Navidad y Halloween)

En el editor, pestaña **Apariencia → Temporadas**, hay un botón **Activar / Desactivar** para cada una. Se ve primero en la vista previa y se aplica al sitio con **Guardar apariencia**. Solo se manejan desde el editor: los visitantes no ven ningún botón. Solo puede haber una activa a la vez (al activar una, la otra se apaga). Mientras una está activa cambia los colores del sitio; al desactivarla vuelven los de antes. Los adornos viven en `admin/temporadas.js`.

## Agregar un creador de contenido nuevo

Lo más fácil es el editor (`/admin/`, botón **Agregar creador**): crea la carpeta, la foto y la página `/creadores/<nombre>` solo.

A mano:

1. Copia la carpeta de otro creador de contenido (por ejemplo `creadores/kimera`) y cámbiale el nombre por el del streamer, en minúsculas, sin tildes ni espacios (usa guiones). Ejemplo: `creadores/mi-streamer`. Esa carpeta ya trae su `index.html`, no lo borres.
2. Abre `creadores/mi-streamer/datos.js` y cambia los textos: nombre, categorías (una lista: `"categorias": ["Gaming", "Cosplay"]`), seguidores, redes, etc. Pon su foto en esa misma carpeta y escribe su nombre en la línea `foto:`.
3. Abre `creadores/lista.js` y agrega una línea con el nombre de la carpeta: `"mi-streamer"`. Cuida que todas las líneas menos la última terminen en coma.

Con eso aparece la tarjeta, el desplegable del menú, su página `/creadores/mi-streamer` y la opción en el formulario de contacto.

## Guardar desde el editor local

Para que los cambios del panel administrador modifiquen las carpetas reales del proyecto, inicia el servidor especial desde la carpeta del proyecto:

```powershell
python servidor_editor.py
```

Después abre `http://127.0.0.1:8000/` para ver el sitio y `http://127.0.0.1:8000/admin/` para el editor. Los botones Guardar actualizarán también `creadores/lista.js`, los archivos `creadores/<creador>/datos.js`, las fotos nuevas y los archivos `secciones/*/contenido.js`. El servidor solo admite conexiones locales.

## Videos, fotos y enlaces de un creador de contenido

En `frames` de su `datos.js` (o en el editor, botón **Agregar enlace**) pega el enlace o el código `<iframe>` y el sitio reconoce de dónde es, pone una etiqueta con la plataforma y arma el reproductor con la proporción correcta. Sin límite de cantidad.

Reconoce: YouTube (videos, shorts, directos, listas), Twitch (directo, video, clip), Kick, TikTok, Instagram (publicaciones y reels), Facebook, X, Spotify, SoundCloud, Vimeo, Dailymotion, Google Drive, fotos sueltas (.jpg, .png...), videos sueltos (.mp4...) y audios (.mp3...). Si el sitio no permite incrustarse, sale un botón "Abrir en ...".

Los enlaces cortos (por ejemplo `vm.tiktok.com`) no se pueden incrustar: usa el enlace completo del video.

## Quitar o reordenar creadores de contenido

Abre `creadores/lista.js`. Borra su línea para quitarlo, o mueve las líneas para cambiar el orden en que salen.

## Cambiar la foto de un creador de contenido

Pon la foto nueva dentro de su carpeta, por ejemplo `creadores/kimera/foto.jpg`, y en su `datos.js` cambia el nombre en la línea `foto:`. Funcionan bien las fotos verticales (proporción 4:5).

## Cambiar textos

- Menú: `secciones/encabezado/contenido.js`
- Título y botones de la portada: `secciones/portada/contenido.js`
- Sobre nosotros: `secciones/nosotros/contenido.js`
- Pie de página y redes de la agencia: `secciones/pie/contenido.js`
- Textos fijos de la página de cada creador de contenido: `secciones/perfil/contenido.js`

## Marcas

En `secciones/clientes/contenido.js` agrega `{ nombre: "Mi Marca", imagen: "mi-marca.png" }` y pon el logo en `secciones/clientes/logos/`. Si no pones imagen, se muestra una ficha con el nombre.

## Editor local

Abre `/admin/` desde el equipo mediante el servidor local. La primera vez crea una contraseña para `FHerrera14`. El editor solo acepta acceso desde `localhost`, `127.0.0.1` o apertura directa por archivo.

El editor permite reemplazar imágenes en creadores de contenido, secciones, logotipo del encabezado y logos de marcas. Los archivos seleccionados se guardan junto a cada sección o creador de contenido, y GitHub Pages los publica con el contenido público. **No publiques la carpeta `admin/`** ni el servidor Python; el sitio publicado seguirá usando los archivos generados por el editor local.

## Cambiar colores y letras

Abre `assets/css/base.css`. Al inicio están los colores y las fuentes con una nota al lado de cada uno. Cambia el valor y se actualiza todo el sitio.

## Reordenar o quitar secciones de la página principal

En `index.html` (inicio) están los bloques `data-seccion="..."` en el orden en que se ven. Mueve un bloque para cambiar su posición, o bórralo para quitar esa sección. Si quitas una, borra también su enlace del menú en `secciones/encabezado/contenido.js`. En el menú y en los botones los destinos se escriben como `creadores/`, `nosotros/`, `contacto/` (o vacío para el inicio); el sitio los convierte solo a `/talentos`, `/nosotros`, etc.

## Formulario de contacto

Por ahora es una maqueta y no envía nada. Dos opciones:

- En `secciones/contacto/contenido.js` escribe tu correo en `correoDestino`. Al enviar, se abre el programa de correo del visitante con el mensaje listo.
- Para recibir mensajes sin que el visitante use su correo, conecta el formulario a un servicio como Formspree o Google Forms.

## Publicarlo en GitHub Pages

Sube los cambios con Git a la rama `main`. Si usas el flujo `.github/workflows/deploy-pages.yml`, publicará automáticamente. El paquete público incluye el sitio, las imágenes y los datos, pero excluye la carpeta `admin/` y el servidor Python.

1. Guarda los cambios desde el panel local.
2. Confirma únicamente los archivos públicos modificados, como creadores de contenido, secciones e imágenes; `admin/` y `servidor_editor.py` quedan excluidos por `.gitignore`.
3. Envía el commit a `main` con `git push`.
4. GitHub publicará la versión nueva desde **Actions**.

Para conectar `dreamersnicaragua.com`, crea un archivo `CNAME` en la raíz con ese dominio y configura el DNS según GitHub Pages.

También puedes subir una copia al servidor, pero GitHub Pages no ejecuta PHP, Python ni el editor visual.

## Si algo no aparece

- Revisa que las comas y las comillas de los archivos `.js` estén completas.
- Si una foto no carga, se muestra la imagen "sin foto". Revisa que el nombre del archivo coincida letra por letra, con mayúsculas.
- Si un creador de contenido no sale, revisa que su carpeta esté escrita igual en `creadores/lista.js`.
- Para ver mensajes de error: en el navegador pulsa F12 y abre la pestaña Consola.

## Datos de ejemplo

Los nombres, números, correos, direcciones e imágenes de este proyecto son de ejemplo. Reemplázalos por los reales antes de publicar.

## Redes sociales, enlaces y total de seguidores

En el editor, cada red lleva tres datos: **plataforma**, **enlace** del perfil y **seguidores** (ej. `3.4K`, `1.2M`, `12500`).

- El enlace convierte el ícono de la red en un botón que abre el perfil (en las tarjetas y en la página del creador de contenido).
- Los **seguidores totales** del creador se suman solos con las cifras de sus redes. Si ninguna red tiene cifra, se usa el número que escribas a mano en "Seguidores totales".
- Los creadores de contenido que ya tenían "usuario" siguen funcionando: el sitio arma el enlace con la plataforma, y al abrirlos en el editor el usuario pasa a enlace.
- Las cifras se pueden escribir a mano o leer solas con el botón **Actualizar seguidores** (abajo).

## Actualizar los seguidores cada semana

1. Abre una terminal en esta carpeta y ejecuta `python servidor_editor.py`; entra a `http://localhost:8000/admin/`.
2. En **Creadores**, pulsa **⟳ Actualizar seguidores**. El programa abre el enlace de cada red, lee el número que muestra la página y lo guarda en el archivo de cada creador de contenido. Al terminar te dice cuántas redes se leyeron y cuáles no.
3. Sube los cambios a GitHub (GitHub Desktop o `git push`). El panel `admin/` no se sube.

Qué esperar: YouTube, TikTok y Facebook/Instagram se leen de la propia página; Twitch y Kick usan un servicio público (decapi.me y la web de Kick). X (Twitter) no se puede leer. Instagram a veces pide iniciar sesión. Si una red falla, se conserva el número anterior y puedes escribirlo a mano. Las plataformas cambian sus páginas sin avisar; el lector está en `lector_seguidores.py`.
El total de un creador suma solo las redes que tienen número: si una falla, complétala a mano para que el total no quede corto.

## Iniciar sesión en tus redes una sola vez (opcional)

Sin sesión, Instagram y X casi nunca se pueden leer. Para que el editor use tu sesión:

1. Instala una sola vez: `pip install playwright` y luego `playwright install chromium`.
2. En el editor pulsa **🔑 Conectar mis redes**. Se abre una ventana de Chromium propia (no tu Chrome): inicia sesión en las redes que uses y ciérrala.
3. La sesión queda guardada en `admin/sesiones/` y no hay que repetirlo; solo si una red te la cierra o vence.
4. Desde entonces **Actualizar seguidores** lee los perfiles con esa sesión. Lo que no se pueda leer así se intenta sin sesión.

Seguridad: quien tenga la carpeta `admin/sesiones/` puede entrar a tus cuentas. No la copies ni la compartas. Está dentro de `admin/`, que `.gitignore` excluye de GitHub (se agregó un `.gitignore`; verifica que `admin/` no aparezca en tus cambios antes de subir). El programa no lee las cookies de tu Chrome normal ni guarda contraseñas: solo la sesión del navegador propio.

## Publicaciones incrustadas (frames)

Los enlaces de la lista `frames` de cada creador de contenido se muestran sin barras de desplazamiento. Instagram y X ajustan su altura solos al contenido. Para Instagram se usa la versión del recuadro sin el texto largo de la publicación; el logo y el nombre de la plataforma salen en la etiqueta de arriba de cada recuadro.

## Si olvidas la contraseña del panel

1. Ten corriendo `python servidor_editor.py`, abre `/admin/` y pulsa **¿Olvidaste tu contraseña?**
2. Pulsa **Enviar código a la terminal**. En la terminal aparece un código de 8 dígitos (vale 10 minutos, máximo 5 intentos).
3. Escribe el código y elige la contraseña nueva.

Solo quien tiene la terminal del servidor puede ver el código. La contraseña se guarda en el navegador (`localStorage`) de la dirección que uses: `localhost` y `127.0.0.1` son direcciones distintas. Usa siempre la misma.

## Verificación en dos pasos (opcional)

En el editor pulsa **🔒 Seguridad** > activar. Agrega en tu app de autenticación (Google Authenticator, Microsoft Authenticator, Authy, 2FAS) una cuenta con "Introducir clave de configuración", escribe la clave que muestra el editor y confirma con un código. Desde entonces, después de la contraseña se pide el código de 6 dígitos. Si pierdes el teléfono, restablece con el código de la terminal: eso desactiva la verificación en dos pasos.

Estas protecciones sirven para el panel local; quien tenga acceso a tu computadora y a tu carpeta puede editar los archivos directamente.

## Apariencia: colores, letras y fondos

En el editor, pestaña **Apariencia** (necesita `python servidor_editor.py`):

- **Temas rápidos:** cambian todos los colores de una vez (Original, Neón morado, Fuego, Esmeralda, Rosa).
- **Colores:** principal, secundario, menú y pie, fondos oscuros, blanco, gris, títulos y texto.
- **Letras:** una fuente de Google para los títulos y otra para el texto.
- **Fondos de cada parte:** menú, portada, creadores de contenido, sobre nosotros, clientes, contacto, perfil y pie. Cada uno puede ser el original, un color liso, un degradado o una imagen (con opción de oscurecerla), y puedes forzar las letras claras u oscuras si el fondo las vuelve difíciles de leer.
- A la derecha hay una **vista previa en vivo**; nada se guarda hasta pulsar **Guardar apariencia**.
- **Restablecer original** y luego Guardar devuelve todo como estaba.

Se guarda en `config/tema.css` (lo cargan todas las páginas), `config/tema.json` y `config/fondos/` (imágenes). Esos archivos sí se suben a GitHub. Si creas páginas nuevas a mano, agrega antes de `</head>`: `<link rel="stylesheet" href="../config/tema.css">` (con los `../` que correspondan).
Algunos brillos pequeños (por ejemplo el resplandor azul de la portada) mantienen su tono original aunque cambies el color principal.

## Likes totales en TikTok

El dato destacado del perfil ahora es **Likes totales en TikTok**. En el editor es un solo campo (ej. `1.2M`). Con **Actualizar seguidores** se llena solo para los creadores que tienen el enlace de su TikTok; si TikTok bloquea la lectura, se conserva el valor anterior y puedes escribirlo a mano. Si el campo está vacío, ese dato no se muestra en el perfil.

## Filtros y orden de creadores de contenido

La sección de creadores de contenido (inicio y página Creadores de contenido) tiene filtros para el visitante:

- **Tipo:** los botones se sacan solos de las categorías de cada creador de contenido. Cada categoría es un texto independiente (en el editor, botón **＋ Agregar** de la lista «Categorías»); ya no se escriben unidas con `/`. Si le cambias o quitas una categoría a un creador y nadie más la tiene, su botón desaparece del filtro solo. Ojo con errores de escritura (por ejemplo «Dacing»): cuentan como una categoría distinta.
- **Seguidores:** menos de 10K, 10K a 50K, 50K a 100K o más de 100K (usa el total sumado de cada creador).
- **Ordenar por:** orden de la agencia, más seguidores, menos seguidores o nombre A-Z.

Los textos de los filtros (incluidas las 4 opciones de seguidores y el mensaje «Mostrando {n} de {total}») se editan cada uno por separado en el panel (Páginas > Sección de creadores). Cuando en la última fila queda un solo creador de contenido, se centra.

## Google Tag Manager

Todas las páginas públicas (inicio, creadores, perfiles, nosotros, contacto y 404) llevan el código de Google con el contenedor `GTM-NQVSWM64`, justo debajo del `viewport` dentro de `<head>`. Las páginas de creadores nuevas que crea el editor ya lo incluyen. El panel `admin/` no lo lleva. Si abres el sitio en tu computadora, esas visitas también cuentan; en Google Tag Manager puedes excluir el host `localhost`.

## Dirección /creadores

La carpeta `talentos/` ahora se llama `creadores/`: la lista es `dreamersmedianicaragua.com/creadores` y cada perfil `…/creadores/<nombre>`. Los enlaces viejos que empiezan con `/talentos` se redirigen solos a `/creadores` desde `404.html` (no borres ese archivo). Por dentro, algunos nombres técnicos (por ejemplo `secciones/talentos`) se mantienen igual; los visitantes no los ven.

## Revisión de ortografía

En el editor, el botón **✓ Revisar ortografía** (arriba) revisa los textos de todos los creadores y de todas las secciones.
- Para cada posible falta muestra la frase, la palabra marcada y hasta 4 sugerencias. Pulsa la sugerencia para corregir, **Ignorar** para dejarla, o **Ignorar siempre** para que esa palabra (nombre propio, marca, apodo) no se marque más. Esas palabras se guardan en `config/ortografia.json`.
- **Corregir todo con la 1.ª sugerencia** aplica todas de una vez (revisa antes que no haya nombres propios).
- No se corrige nada sin que lo pulses: así no se dañan nombres, marcas ni apodos.
- Usa el corrector gratuito LanguageTool: necesita internet y los textos se envían a ese servicio. Para no enviar nada fuera, instala LanguageTool en tu PC y ejecuta el servidor con `DREAMERS_LT_URL=http://localhost:8010/v2/check`.
- Además, los campos de texto del editor subrayan en rojo las faltas mientras escribes (corrector del navegador, en español).

## Carrusel automático de contenido (5 por creador)

En la página de cada creador, «Videos y transmisiones» es ahora un **carrusel** (3 a la vez en PC, 2 en tablet, 1 en teléfono; se desliza con el dedo o con las flechas/puntos).
Ya no hay que pegar enlaces a mano: el contenido se elige solo a partir de los enlaces de redes del creador.

1. En el editor entra a **Carrusel** y pulsa **▶ Actualizar todos** (o **⟳ Actualizar** en un creador).
2. El servidor busca publicaciones recientes (TikTok, YouTube, Instagram, X, Facebook; Twitch y Kick muestran su canal) y **comprueba que cada una se pueda mostrar dentro de la página** (oEmbed / página de inserción). Las restringidas se descartan y entra la siguiente.
3. Se mezclan las redes (por turnos) y quedan **5 elegidas** + hasta 8 de **reserva** en `creadores/<carpeta>/auto.js`.
4. En la página pública, si un YouTube de la lista deja de poder insertarse, se cambia solo por uno de la reserva.
5. Sube los cambios a GitHub (incluida cada `auto.js`).

Notas honestas:
- Instagram, Facebook y X casi siempre piden iniciar sesión: usa **«Conectar mis redes»** una vez y el servidor las leerá con tu sesión. Sin sesión puede que solo salgan TikTok/YouTube/Twitch/Kick.
- Si de un creador se encuentran menos de 5 contenidos válidos, el carrusel muestra los que haya y el editor lo avisa en «Resumen».
- Los enlaces escritos a mano en el creador (campo de videos) siguen funcionando: se usan **solo si faltan** contenidos automáticos para llegar a 5.
- Las redes cambian sus páginas: si una dejó de leerse, vuelve a pulsar Actualizar en unos días.
- Repite «Actualizar seguidores» y «Actualizar carrusel» cada semana antes de subir a GitHub.

## Editor rediseñado

El panel ahora tiene menú lateral (PC y tablet) o barra inferior (teléfono) con secciones independientes: **Resumen**, **Creadores**, **Carrusel**, **Páginas** y **Apariencia**. «Más opciones» (arriba a la derecha) tiene revisar ortografía, ver sitio, seguridad y cerrar sesión. En el teléfono las ventanas de edición ocupan toda la pantalla.
Estructura: `admin/css/` (base, layout, componentes, resumen, contenido) y `admin/modulos/` (navegacion, resumen, contenido). El formulario de agregar/editar creadores no se modificó.

## Foto automática desde las redes

Si un creador no tiene foto (o su archivo de foto no existe), el botón **🖼 Traer fotos faltantes** (en Creadores y en Resumen) busca la foto de perfil en sus redes (orden: Instagram, TikTok, YouTube, Twitch, Facebook, X, Kick), la **descarga** a `creadores/<carpeta>/foto-redes.<jpg|png|webp>` y la pone como su foto. Se guarda en el proyecto porque los enlaces de las redes caducan.
- Si Instagram/Facebook/X piden iniciar sesión, usa antes «Conectar mis redes».
- Es la imagen pública del perfil, normalmente pequeña y cuadrada: úsala solo con permiso del creador y cámbiala por una foto propia cuando la tengan.
- Nunca reemplaza una foto que ya existe. Después puedes encuadrarla con Editar (posición y zoom).

## Contactar a un creador (diferente al contacto de la página)

El botón **Contratar** del perfil de cada creador abre una ventana propia, distinta del formulario de la página «Contacto»:
- Muestra **una opción por cada red del creador** (Instagram, TikTok, YouTube...). Al elegirla se abre directamente su cuenta en una pestaña nueva.
- Aparece **«Escribirle por correo»** solo si en su ficha (Editor → Creadores → Editar) escribiste el campo **Correo de contacto (opcional)**. Ese correo es público en la página. Al elegirla sale un formulario (nombre, correo, empresa, mensaje) y dos botones: **Abrir en mi correo** (mailto) y **Abrir en Gmail**. Un sitio en GitHub Pages no puede enviar correos por sí solo: el mensaje sale desde el correo de quien escribe.
- Si el creador no tiene redes ni correo, ofrece contactar a la agencia.
- Todos los textos de esa ventana están en `secciones/perfil/contenido.js` (editor → Páginas → perfil).
- El formulario de la página **Contacto** quedó solo para la agencia (ya no tiene «Creador de interés»).

## Vista previa al compartir y SEO

Pestaña **Buscadores** del editor. Cada vez que guardas, el servidor escribe en el `<head>` de cada página: título, descripción, enlace canónico, etiquetas Open Graph y Twitter (lo que usan WhatsApp, Facebook, Instagram, X) y datos estructurados para Google. También crea:
- `creadores/<carpeta>/compartir.jpg`: imagen 1200×630 de cada creador (foto, nombre, categorías, seguidores). Necesita Pillow (`pip install pillow`); sin él se usa la foto o la imagen general `assets/img/compartir.jpg`.
- `sitemap.xml` y `robots.txt` (usan el dominio del archivo `CNAME`).
- Los textos de Inicio, Creadores, Nosotros y Contacto se editan en la pestaña Buscadores (se guardan en `config/seo.json`).

Después de subir a GitHub, registra el sitio en **Google Search Console** y envía `https://tu-dominio/sitemap.xml`. Para probar la tarjeta: https://developers.facebook.com/tools/debug/ (si WhatsApp muestra una vista vieja, pulsa «Scrape Again»). Los cambios tardan en reflejarse en Google (días).

## Novedades v20

- **Textos extra**: Páginas → «Textos extra». Agrega bloques (título + párrafos) en Inicio, Creadores, Nosotros o Contacto, con posición, alineación, tamaño, fondo y color propios.
- **Color individual por texto**: en cada campo de texto de Páginas hay «Estilo propio» (color, tamaño, negrita). Es independiente de Apariencia; los temas no lo cambian.
- **Navidad y Halloween rediseñados**: ya no hay capa que tape texto. Las partículas viven en los márgenes libres (pantallas anchas), huyen del cursor, y un toque/clic suelta una ráfaga pequeña. El encabezado y el pie reaccionan al pasar el mouse. Respeta «reducir movimiento».
- **⚡ Actualizar todo**: seguidores + carrusel + fotos faltantes, en orden. Los botones sueltos siguen igual.
- **Elegir videos**: en «Carrusel» → «Elegir videos» (y se abre solo si la forma automática no llega a 5). Muestra, por plataforma, los videos que sí se pueden mostrar; también puedes pegar un enlace. Lo elegido se conserva al actualizar.

## Novedades v21 (velocidad)

- **Fotos ligeras**: al subir una foto, el editor la reduce (máx. 1000 px) y la guarda en WebP (de ~2 MB a ~60 KB). Las fotos que ya estaban se optimizaron (de 19 MB a 3 MB en total). Si algún día pegas fotos pesadas a mano en `creadores/`, ejecuta `python imagenes.py` (necesita `pip install pillow`).
- **Un solo archivo de creadores**: el editor genera `creadores/todos.js` al guardar; la página lo carga en 1 petición en vez de 20+. Si falta, carga como antes.
- **Caché**: los datos se vuelven a pedir cada 10 minutos (lo que dura la caché de GitHub Pages), no en cada visita.
- **Letras sin bloquear**: las fuentes de Google cargan en segundo plano. Guarda de nuevo «Apariencia» una vez para que el tema use el nuevo formato.
- Las imágenes de las tarjetas cargan perezosamente; la foto principal del perfil carga con prioridad.

## Novedades v22 (accesibilidad y carga)

- Scripts con `defer`: ya no bloquean el primer dibujo de la página.
- Contraste: el filtro activo y los nombres de marcas ahora cumplen el mínimo (4.5:1).
- Títulos en orden (h1 → h2 → h3) en inicio, listado y perfiles.
- Los nombres de las tarjetas son más fáciles de tocar en el celular (24 px mínimo).


## Novedades v23-v24

- **Modo oscuro**: botón luna/sol en el encabezado; sigue la preferencia del dispositivo y recuerda la elección del visitante. Colores al final de `assets/css/base.css`.
- Los archivos CSS/JS llevan `?v=24` para forzar la descarga tras subir una versión; si algo nuevo no aparece, Ctrl+F5.
