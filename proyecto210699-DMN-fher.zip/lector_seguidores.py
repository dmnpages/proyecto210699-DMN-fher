"""Lee el número de seguidores que muestran las páginas públicas de cada red.

Lo usa servidor_editor.py cuando pulsas "Actualizar seguidores" en el editor.
No usa APIs con clave: abre el enlace del perfil, como lo haría un navegador, y busca el número en la página.
Las plataformas cambian sus páginas o bloquean visitas automáticas, así que a veces una red no se puede leer.
En ese caso se avisa y se conserva el número que ya estaba escrito.
"""
import json, re, urllib.error, urllib.parse, urllib.request
from concurrent.futures import ThreadPoolExecutor

NAVEGADOR = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
             "Chrome/124.0 Safari/537.36")
SUFIJO = r"\d[\d.,]*(?:\s?(?:[KkMm]|mil|millones|millón|million)\b)?"

# Dominios permitidos (el servidor solo visita estos).
DOMINIOS = {
    "instagram": ("instagram.com",), "tiktok": ("tiktok.com",), "youtube": ("youtube.com", "youtu.be"),
    "facebook": ("facebook.com", "fb.com"), "twitch": ("twitch.tv",), "kick": ("kick.com",), "x": ("x.com", "twitter.com"),
}
ALIAS = {"twitter": "x"}


def plataforma_de(plataforma, enlace):
    """Detecta la red por el dominio del enlace (o por el nombre si el dominio no se reconoce)."""
    host = (urllib.parse.urlparse(enlace).hostname or "").lower()
    for nombre, dominios in DOMINIOS.items():
        if any(host == d or host.endswith("." + d) for d in dominios):
            return nombre
    nombre = (plataforma or "").strip().lower()
    return ALIAS.get(nombre, nombre)


def descargar(url, extra=None):
    cabeceras = {"User-Agent": NAVEGADOR, "Accept-Language": "en-US,en;q=0.9", "Accept": "text/html,application/json;q=0.9,*/*;q=0.8",
                 "Cookie": "CONSENT=YES+1; SOCS=CAI"}
    cabeceras.update(extra or {})
    peticion = urllib.request.Request(url, headers=cabeceras)
    with urllib.request.urlopen(peticion, timeout=15) as r:
        return r.read(3_000_000).decode("utf-8", "replace")


def limpiar(texto):
    return re.sub(r"\s+", "", texto or "").strip()


def meta_descripcion(html):
    for patron in (r'<meta[^>]+property=["\']og:description["\'][^>]+content=["\']([^"\']*)',
                   r'<meta[^>]+content=["\']([^"\']*)["\'][^>]+property=["\']og:description["\']',
                   r'<meta[^>]+name=["\']description["\'][^>]+content=["\']([^"\']*)'):
        m = re.search(patron, html, re.I)
        if m:
            return m.group(1)
    return ""


def antes_de(palabras, texto):
    m = re.search(r"(" + SUFIJO + r")\s*(?:" + palabras + r")(?![a-zA-Z])", texto, re.I)
    return limpiar(m.group(1)) if m else None


def leer_youtube(html):
    m = re.search(r'"subscriberCountText"\s*:\s*\{.{0,400}?"(?:simpleText|content)"\s*:\s*"([^"]+)"', html, re.S)
    if m:
        n = antes_de(r"subscribers?|suscriptores|abonn\w+", m.group(1))
        if n:
            return n
    return antes_de(r"subscribers?|suscriptores", meta_descripcion(html)) or antes_de(r"subscribers?|suscriptores", html)


def leer_tiktok(html):
    m = re.search(r'"followerCount"\s*:\s*(\d+)', html)
    if m:
        return m.group(1)
    return antes_de(r"followers?|seguidores", meta_descripcion(html))


def leer_likes_tiktok(html):
    m = re.search(r'"heartCount"\s*:\s*(\d+)', html) or re.search(r'"heart"\s*:\s*(\d+)', html)
    return m.group(1) if m else None


def leer_og(html):
    return antes_de(r"followers?|seguidores|subscribers?|suscriptores", meta_descripcion(html))


def leer_facebook(html):
    d = meta_descripcion(html)
    return antes_de(r"followers?|seguidores", d) or antes_de(r"likes|me gusta", d)


def twitch(enlace):
    canal = urllib.parse.urlparse(enlace).path.strip("/").split("/")[0]
    if not re.fullmatch(r"[A-Za-z0-9_]{2,25}", canal or ""):
        raise ValueError("No se reconoce el canal de Twitch en el enlace.")
    # Twitch no muestra los seguidores en su página sin sesión; se consulta un servicio público de lectura (decapi.me).
    texto = descargar("https://decapi.me/twitch/followcount/" + canal).strip()
    return limpiar(texto) if re.fullmatch(r"[\d.,]+", texto) else None


def kick(enlace):
    canal = urllib.parse.urlparse(enlace).path.strip("/").split("/")[0]
    if not re.fullmatch(r"[A-Za-z0-9_-]{2,40}", canal or ""):
        raise ValueError("No se reconoce el canal de Kick en el enlace.")
    datos = json.loads(descargar("https://kick.com/api/v2/channels/" + canal))
    n = datos.get("followers_count") or datos.get("followersCount")
    return str(n) if n else None


LECTORES = {"youtube": leer_youtube, "tiktok": leer_tiktok, "instagram": leer_og, "facebook": leer_facebook}
SIN_SOPORTE = {"x": "X (Twitter) pide iniciar sesión para ver los seguidores; escríbelo a mano."}


def leer_uno(plataforma, enlace):
    """Devuelve {'ok': True, 'seguidores': '12345'} o {'ok': False, 'error': '...'}."""
    try:
        partes = urllib.parse.urlparse(enlace)
        if partes.scheme not in ("http", "https") or not partes.hostname:
            return {"ok": False, "error": "El enlace no es válido."}
        red = plataforma_de(plataforma, enlace)
        if red in SIN_SOPORTE:
            return {"ok": False, "error": SIN_SOPORTE[red]}
        if red not in DOMINIOS:
            return {"ok": False, "error": "Esta red no se puede leer sola; escríbelo a mano."}
        if not any(partes.hostname == d or partes.hostname.endswith("." + d) for d in DOMINIOS[red]):
            return {"ok": False, "error": "El enlace no corresponde a " + red + "."}
        if red == "twitch":
            n = twitch(enlace)
        elif red == "kick":
            n = kick(enlace)
        elif red == "tiktok":
            pagina = descargar(enlace)
            n = leer_tiktok(pagina)
            if n:
                return {"ok": True, "seguidores": n, "likes": leer_likes_tiktok(pagina)}
        else:
            n = LECTORES[red](descargar(enlace))
        if not n:
            return {"ok": False, "error": "No se encontró el número en la página (puede estar bloqueada o haber cambiado)."}
        return {"ok": True, "seguidores": n}
    except urllib.error.HTTPError as e:
        return {"ok": False, "error": "La página respondió con error %s." % e.code}
    except Exception as e:  # sin internet, tiempo agotado, etc.
        return {"ok": False, "error": "No se pudo abrir la página (%s)." % (str(e)[:80] or type(e).__name__)}


def leer_varios(redes):
    """redes: lista de {id, plataforma, enlace}. Devuelve la misma lista con el resultado de cada una."""
    redes = [r for r in redes if isinstance(r, dict)][:200]
    with ThreadPoolExecutor(max_workers=8) as pool:
        resultados = list(pool.map(lambda r: leer_uno(str(r.get("plataforma", "")), str(r.get("enlace", ""))), redes))
    return [dict(res, id=r.get("id")) for r, res in zip(redes, resultados)]
