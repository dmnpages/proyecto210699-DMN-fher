"""Elige solo el contenido que se mostrará en el carrusel de cada creador.

A partir de los enlaces de redes de cada creador:
  1. Busca publicaciones recientes (en la página pública o, si guardaste sesión, con tu navegador propio).
  2. Comprueba que cada una se pueda mostrar dentro de otra página (oEmbed / página de inserción).
  3. Descarta las restringidas y deja 5 elegidas (mezclando redes) más algunas de reserva.
El resultado se guarda en creadores/<carpeta>/auto.js. La página pública solo lee ese archivo (no consulta redes).
Lo usa servidor_editor.py (botón "Actualizar contenido"). No usa APIs con clave.
"""
import json, re, time, urllib.error, urllib.parse, urllib.request
from concurrent.futures import ThreadPoolExecutor
import lector_seguidores as L

ELEGIDOS = 5
RESERVA = 8
POR_RED = 10          # candidatas que se comprueban por red
RED_ORDEN = ["tiktok", "youtube", "instagram", "twitch", "kick", "facebook", "x"]


def _get(url, extra=None):
    """(estado, texto). No lanza error con 4xx para poder interpretar la respuesta."""
    cab = {"User-Agent": L.NAVEGADOR, "Accept-Language": "es-ES,es;q=0.9,en;q=0.8", "Cookie": "CONSENT=YES+1; SOCS=CAI"}
    cab.update(extra or {})
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers=cab), timeout=12) as r:
            return r.status, r.read(1_500_000).decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, ""
    except Exception:
        return 0, ""


def _unicas(lista):
    visto, salida = set(), []
    for x in lista:
        if x not in visto:
            visto.add(x)
            salida.append(x)
    return salida


def usuario_de(enlace):
    ruta = urllib.parse.urlparse(enlace).path.strip("/").split("/")
    return ruta[0].lstrip("@") if ruta and ruta[0] else ""


def urls_en(red, texto, perfil):
    """Saca de un texto (HTML o lista de enlaces) las URLs de publicaciones de esa red."""
    texto = (texto or "").replace("\\u002F", "/").replace("\\/", "/")
    usuario = usuario_de(perfil)
    if red == "tiktok":
        ids = re.findall(r"/video/(\d{15,22})", texto)
        return ["https://www.tiktok.com/@%s/video/%s" % (usuario, i) for i in _unicas(ids)]
    if red == "youtube":
        ids = re.findall(r"(?:watch\?v=|/shorts/|<yt:videoId>)([\w-]{11})", texto)
        return ["https://www.youtube.com/watch?v=" + i for i in _unicas(ids)]
    if red == "instagram":
        pares = re.findall(r"instagram\.com/(?:[\w.]+/)?(p|reel)/([\w-]{6,})", texto) or re.findall(r"/(p|reel)/([\w-]{6,})/", texto)
        return ["https://www.instagram.com/%s/%s/" % (k, i) for k, i in _unicas(pares)]
    if red == "x":
        ids = re.findall(r"/status/(\d{10,22})", texto)
        return ["https://x.com/%s/status/%s" % (usuario or "i", i) for i in _unicas(ids)]
    if red == "facebook":
        return _unicas(re.findall(r"https://(?:www\.|web\.)?facebook\.com/[\w./-]*?(?:videos|reel)/\d+/?", texto))
    return []


# ---- Comprobación de que se puede incrustar
def _oembed(url_oembed):
    est, cuerpo = _get(url_oembed)
    titulo = ""
    if est == 200:
        try:
            titulo = str(json.loads(cuerpo).get("title") or "")[:90]
        except Exception:
            titulo = ""
    return est == 200, titulo


def info_embed(red, url):
    """Devuelve (se_puede_incrustar, titulo)."""
    q = urllib.parse.quote(url, safe="")
    if red == "tiktok":
        return _oembed("https://www.tiktok.com/oembed?url=" + q)
    if red == "youtube":
        return _oembed("https://www.youtube.com/oembed?format=json&url=" + q)
    if red == "x":
        return _oembed("https://publish.twitter.com/oembed?url=" + q)
    if red == "instagram":
        est, html = _get(url.rstrip("/") + "/embed/")
        return (est == 200 and not re.search(r"no est[aá] disponible|isn.t available|Sorry, this|Restricted|contenido no disponible", html, re.I)), ""
    return True, ""  # Facebook / directos: no hay comprobación fiable sin sesión


def se_puede_mostrar(red, url):
    return info_embed(red, url)[0]


def candidatas_http(red, enlace):
    """Candidatas leyendo la página pública, sin iniciar sesión."""
    usuario = usuario_de(enlace)
    if red == "twitch" and usuario:
        return ["https://www.twitch.tv/" + usuario]
    if red == "kick" and usuario:
        return ["https://kick.com/" + usuario]
    if red == "youtube":
        est, html = _get(enlace)
        canal = re.search(r'"(?:channelId|externalId)":"(UC[\w-]{22})"|channel_id=(UC[\w-]{22})', html)
        if canal:
            est2, feed = _get("https://www.youtube.com/feeds/videos.xml?channel_id=" + (canal.group(1) or canal.group(2)))
            if est2 == 200:
                return urls_en(red, feed, enlace)
        return urls_en(red, html, enlace)
    if red in ("tiktok", "instagram", "x", "facebook"):
        return urls_en(red, _get(enlace)[1], enlace)
    return []


def descubrir(redes, cosechadas=None, fijados=None):
    """redes: [{plataforma, enlace}] de un creador. cosechadas: {enlace: texto con enlaces} leídos con el navegador.
    Devuelve {elegidos: [...], reserva: [...], resumen: [...]}."""
    cosechadas = cosechadas or {}
    por_red, resumen, titulos = {}, [], {}
    for r in redes:
        enlace = str(r.get("enlace", "")).strip()
        red = L.plataforma_de(r.get("plataforma", ""), enlace)
        host = urllib.parse.urlparse(enlace).hostname or ""
        if not enlace or red not in L.DOMINIOS or not any(host == d or host.endswith("." + d) for d in L.DOMINIOS[red]):
            continue
        cands = urls_en(red, cosechadas.get(enlace, ""), enlace) if cosechadas.get(enlace) else []
        for u in candidatas_http(red, enlace):
            if u not in cands:
                cands.append(u)
        cands = cands[:POR_RED]
        with ThreadPoolExecutor(max_workers=5) as ex:
            infos = list(ex.map(lambda u: info_embed(red, u), cands))
        buenas = [u for u, (ok, _) in zip(cands, infos) if ok]
        for u, (ok, titulo) in zip(cands, infos):
            if ok and u not in titulos:
                titulos[u] = titulo
        por_red.setdefault(red, []).extend(buenas)
        resumen.append({"red": red, "encontradas": len(cands), "validas": len(buenas), "restringidas": len(cands) - len(buenas)})
    # Mezcla las redes por turnos para que el carrusel no sea todo de una sola.
    orden = [x for x in RED_ORDEN if x in por_red] + [x for x in por_red if x not in RED_ORDEN]
    mezcla = []
    for i in range(POR_RED):
        for red in orden:
            if i < len(por_red[red]):
                mezcla.append(por_red[red][i])
    fijados = _unicas([u for u in (fijados or []) if isinstance(u, str) and u.startswith("http")])[:ELEGIDOS]
    mezcla = _unicas(fijados + mezcla)
    candidatas = [{"red": red, "url": u, "titulo": titulos.get(u, "")} for red in orden for u in por_red[red]]
    return {"elegidos": mezcla[:ELEGIDOS], "reserva": mezcla[ELEGIDOS:ELEGIDOS + RESERVA], "resumen": resumen,
            "fijados": fijados, "candidatas": candidatas}


def texto_auto_js(carpeta, datos):
    cuerpo = {"actualizado": time.strftime("%Y-%m-%d"), "elegidos": datos["elegidos"], "reserva": datos["reserva"]}
    if datos.get("fijados"):
        cuerpo["fijados"] = datos["fijados"]
    if datos.get("candidatas"):
        cuerpo["candidatas"] = datos["candidatas"]
    return "Dreamers.autoContenido(%s, %s);\n" % (json.dumps(carpeta), json.dumps(cuerpo, ensure_ascii=False, indent=2))
