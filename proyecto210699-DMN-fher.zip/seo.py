"""SEO y vista previa al compartir (WhatsApp, Facebook, Instagram, X, Google...).

Los buscadores y las apps de mensajería NO ejecutan JavaScript: leen las etiquetas que están escritas en cada HTML. Por eso este módulo
las escribe en el <head> de cada página (entre <!-- SEO --> y <!-- /SEO -->), genera la imagen de vista previa de cada creador
(creadores/<carpeta>/compartir.jpg), sitemap.xml y robots.txt. Lo ejecuta servidor_editor.py cada vez que guardas.
Los textos de las páginas se editan en config/seo.json (o en la pestaña «Buscadores» del editor).
"""
import datetime, html, json, re
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
CONFIG = RAIZ / "config" / "seo.json"
IMG_SITIO = "assets/img/compartir.jpg"

DEFECTO = {
    "sitio": "Dreamers Media Nicaragua",
    "descripcion": "La vitrina oficial del streaming y el contenido digital en Nicaragua. Conoce a los creadores de contenido, sus redes y contáctalos.",
    "paginas": {
        "inicio": {"titulo": "Dreamers Media Nicaragua | Streamers y creadores de contenido",
                   "descripcion": "La vitrina oficial del streaming y el contenido digital en Nicaragua. Conoce a los streamers y creadores de contenido de nuestra agencia."},
        "creadores": {"titulo": "Creadores de contenido | Dreamers Media Nicaragua",
                      "descripcion": "Streamers, cosplayers, músicos y creadores de contenido de Nicaragua. Filtra por tipo y seguidores y conoce sus redes."},
        "nosotros": {"titulo": "Sobre nosotros | Dreamers Media Nicaragua",
                     "descripcion": "Somos la vitrina oficial del streaming y el contenido digital en Nicaragua: conectamos a creadores de contenido con marcas y audiencias."},
        "contacto": {"titulo": "Contacto | Dreamers Media Nicaragua",
                     "descripcion": "Escríbenos para colaborar con los creadores de contenido de Dreamers Media Nicaragua."},
    },
    "creadorTitulo": "{nombre} | {sitio}",
    "creadorDescripcion": "{descripcion}",
    "creadorSinDescripcion": "{nombre}, creador de contenido de Nicaragua. Conoce sus redes y contáctalo con Dreamers Media Nicaragua.",
}
PAGINAS = {"inicio": "index.html", "creadores": "creadores/index.html", "nosotros": "nosotros/index.html", "contacto": "contacto/index.html"}
URLS = {"inicio": "", "creadores": "creadores/", "nosotros": "nosotros/", "contacto": "contacto/"}


def config():
    datos = json.loads(json.dumps(DEFECTO))
    try:
        guardado = json.loads(CONFIG.read_text(encoding="utf-8"))
        for k, v in guardado.items():
            if k == "paginas" and isinstance(v, dict):
                for p, campos in v.items():
                    if p in datos["paginas"] and isinstance(campos, dict):
                        datos["paginas"][p].update({c: str(x) for c, x in campos.items() if c in ("titulo", "descripcion")})
            elif k in datos and isinstance(v, str):
                datos[k] = v
    except Exception:
        pass
    return datos


def guardar_config(nuevo):
    base = config()
    limpio = {}
    for k in ("sitio", "descripcion", "creadorTitulo", "creadorDescripcion", "creadorSinDescripcion"):
        limpio[k] = str(nuevo.get(k, base[k])).strip()[:300] or base[k]
    limpio["paginas"] = {}
    for p in PAGINAS:
        src = (nuevo.get("paginas") or {}).get(p, {})
        limpio["paginas"][p] = {c: (str(src.get(c, base["paginas"][p][c])).strip()[:300] or base["paginas"][p][c]) for c in ("titulo", "descripcion")}
    CONFIG.parent.mkdir(exist_ok=True)
    CONFIG.write_text(json.dumps(limpio, ensure_ascii=False, indent=2), encoding="utf-8")


def dominio():
    try:
        d = (RAIZ / "CNAME").read_text(encoding="utf-8").strip().splitlines()[0].strip()
        return re.sub(r"^https?://", "", d).strip("/") or None
    except Exception:
        return None


def _recortar(texto, largo=200):
    texto = re.sub(r"\s+", " ", str(texto or "")).strip()
    if len(texto) <= largo:
        return texto
    return texto[:largo].rsplit(" ", 1)[0].rstrip(" ,.;:") + "…"


def _leer_creador(carpeta):
    ruta = RAIZ / "creadores" / carpeta / "datos.js"
    s = ruta.read_text(encoding="utf-8")
    return json.loads(s[s.index("{"):s.rindex("}") + 1])


def _categorias(t):
    c = t.get("categorias")
    if isinstance(c, list):
        return [str(x) for x in c if str(x).strip()]
    return [str(t.get("categoria"))] if t.get("categoria") else []


# ---------- Imagen de vista previa de cada creador (1200x630)
def _fuente(tam, negrita=True):
    try:
        from PIL import ImageFont
    except Exception:
        return None
    candidatas = (["C:/Windows/Fonts/segoeuib.ttf", "C:/Windows/Fonts/arialbd.ttf", "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
                   "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf"] if negrita else
                  ["C:/Windows/Fonts/segoeui.ttf", "C:/Windows/Fonts/arial.ttf", "/System/Library/Fonts/Supplemental/Arial.ttf",
                   "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf"])
    for c in candidatas:
        try:
            return ImageFont.truetype(c, tam)
        except Exception:
            continue
    return None


def _firma(t, carpeta, foto):
    d = [t.get("nombre"), _categorias(t), t.get("seguidores"), t.get("foto"), t.get("posicionFoto"), t.get("fotoZoom")]
    try:
        e = foto.stat()
        d += [e.st_size, int(e.st_mtime)]
    except Exception:
        pass
    return json.dumps(d, ensure_ascii=False, sort_keys=True)


def crear_tarjeta(carpeta, t):
    """Crea creadores/<carpeta>/compartir.jpg. Devuelve True si hay imagen lista (nueva o ya vigente)."""
    try:
        from PIL import Image, ImageDraw
    except Exception:
        return False
    nombre_foto = str(t.get("foto") or "")
    if not nombre_foto or nombre_foto.startswith(("data:", "http")) or nombre_foto.endswith(".svg"):
        return False
    foto = RAIZ / "creadores" / carpeta / nombre_foto
    destino = RAIZ / "creadores" / carpeta / "compartir.jpg"
    if not foto.is_file():
        return False
    firma = _firma(t, carpeta, foto)
    try:
        if destino.is_file() and Image.open(destino).info.get("comment", b"").decode("utf-8", "ignore") == firma:
            return True
    except Exception:
        pass
    f_nombre, f_peq, f_gran = _fuente(66), _fuente(30, False), _fuente(86)
    if not f_nombre:
        return False
    W, H, FW = 1200, 630, 504
    lienzo = Image.new("RGB", (W, H), "#070a12")
    d = ImageDraw.Draw(lienzo)
    for y in range(H):  # degradado vertical
        k = y / H
        d.line([(0, y), (W, y)], fill=(int(7 + 6 * k), int(10 + 16 * k), int(18 + 40 * k)))
    resplandor = Image.new("RGB", (W, H), (0, 0, 0))
    ImageDraw.Draw(resplandor).ellipse([700, -250, 1450, 400], fill=(46, 80, 160))
    from PIL import ImageFilter, ImageChops
    lienzo = ImageChops.add(lienzo, resplandor.filter(ImageFilter.GaussianBlur(140)))
    d = ImageDraw.Draw(lienzo)
    # Foto a la izquierda, recortada como en la tarjeta del sitio
    im = Image.open(foto).convert("RGB")
    iw, ih = im.size
    ar = FW / H
    bw, bh = (ih * ar, ih) if iw / ih > ar else (iw, iw / ar)
    try:
        zoom = max(1.0, float(t.get("fotoZoom") or 1))
    except Exception:
        zoom = 1.0
    bw, bh = bw / zoom, bh / zoom
    try:
        px, py = [min(100.0, max(0.0, float(v.strip("% ")))) for v in str(t.get("posicionFoto") or "50% 50%").split()[:2]]
    except Exception:
        px, py = 50.0, 50.0
    x0, y0 = (iw - bw) * px / 100, (ih - bh) * py / 100
    lienzo.paste(im.crop((int(x0), int(y0), int(x0 + bw), int(y0 + bh))).resize((FW, H), Image.LANCZOS), (0, 0))
    d.rectangle([FW, 0, FW + 6, H], fill=(46, 163, 242))
    # Texto
    x, ancho = FW + 56, W - FW - 56 - 48
    d.text((x, 60), "DREAMERS MEDIA NICARAGUA", font=f_peq, fill=(46, 163, 242))
    palabras, lineas, actual = str(t.get("nombre") or "").upper().split(), [], ""
    for p in palabras:
        prueba = (actual + " " + p).strip()
        if d.textlength(prueba, font=f_nombre) <= ancho or not actual:
            actual = prueba
        else:
            lineas.append(actual)
            actual = p
    lineas.append(actual)
    y = 130
    for ln in lineas[:3]:
        d.text((x, y), ln, font=f_nombre, fill="white")
        y += 78
    cats = " · ".join(_categorias(t)[:3])
    if cats:
        d.text((x, y + 10), cats, font=f_peq, fill=(190, 205, 230))
    seg = str(t.get("seguidores") or "").strip()
    if seg:
        d.text((x, H - 210), seg + "+", font=f_gran, fill=(46, 163, 242))
        d.text((x, H - 105), "seguidores en redes", font=f_peq, fill=(190, 205, 230))
    destino.parent.mkdir(exist_ok=True)
    lienzo.save(destino, "JPEG", quality=86, optimize=True, comment=firma.encode("utf-8"))
    return True


# ---------- Etiquetas
def _a(s):
    return html.escape(str(s), quote=True)


def _bloque(titulo, descripcion, url, imagen, tipo="website", noindex=False, json_ld=None, cfg=None):
    cfg = cfg or config()
    l = ["<!-- SEO -->", "<title>%s</title>" % html.escape(titulo), '<meta name="description" content="%s">' % _a(descripcion)]
    l.append('<meta name="robots" content="%s">' % ("noindex, follow" if noindex else "index, follow, max-image-preview:large"))
    if url:
        l.append('<link rel="canonical" href="%s">' % _a(url))
    l += ['<meta property="og:type" content="%s">' % tipo, '<meta property="og:site_name" content="%s">' % _a(cfg["sitio"]), '<meta property="og:locale" content="es_NI">',
          '<meta property="og:title" content="%s">' % _a(titulo), '<meta property="og:description" content="%s">' % _a(descripcion)]
    if url:
        l.append('<meta property="og:url" content="%s">' % _a(url))
    if imagen:
        l += ['<meta property="og:image" content="%s">' % _a(imagen), '<meta property="og:image:alt" content="%s">' % _a(titulo)]
    l += ['<meta name="twitter:card" content="%s">' % ("summary_large_image" if imagen else "summary"), '<meta name="twitter:title" content="%s">' % _a(titulo),
          '<meta name="twitter:description" content="%s">' % _a(descripcion)]
    if imagen:
        l.append('<meta name="twitter:image" content="%s">' % _a(imagen))
    l.append('<meta name="theme-color" content="#070a12">')
    if json_ld:
        l.append('<script type="application/ld+json">%s</script>' % json.dumps(json_ld, ensure_ascii=False).replace("</", "<\\/"))
    l.append("<!-- /SEO -->")
    return "\n".join(l) + "\n"


def _insertar(ruta, bloque):
    s = ruta.read_text(encoding="utf-8")
    s = re.sub(r"<!-- SEO -->.*?<!-- /SEO -->\n?", "", s, flags=re.S)
    s = re.sub(r"[ \t]*<title>.*?</title>\n?", "", s, count=1, flags=re.S)
    if "<!-- End Google Tag Manager -->\n" in s:
        s = s.replace("<!-- End Google Tag Manager -->\n", "<!-- End Google Tag Manager -->\n" + bloque, 1)
    else:
        s, n = re.subn(r'(<meta name="viewport"[^>]*>\n)', lambda m: m.group(1) + bloque, s, count=1)
        if not n:
            return False
    ruta.write_text(s, encoding="utf-8")
    return True


def sincronizar():
    """Reescribe etiquetas SEO de todas las páginas, imágenes de vista previa, sitemap.xml y robots.txt."""
    cfg, dom = config(), dominio()
    base = ("https://" + dom + "/") if dom else ""
    hoy = datetime.date.today().isoformat()
    img_sitio = (base + IMG_SITIO) if (dom and (RAIZ / IMG_SITIO).is_file()) else ""
    resumen = {"paginas": 0, "creadores": 0, "tarjetas": 0}
    urls = []
    org = {"@context": "https://schema.org", "@type": "Organization", "name": cfg["sitio"], "url": base or None, "logo": (base + "assets/img/favicon.svg") if base else None}
    org = {k: v for k, v in org.items() if v}
    for clave, archivo in PAGINAS.items():
        ruta = RAIZ / archivo
        if not ruta.is_file():
            continue
        p = cfg["paginas"][clave]
        url = base + URLS[clave] if base else ""
        if _insertar(ruta, _bloque(p["titulo"], p["descripcion"], url, img_sitio, json_ld=org if clave == "inicio" else None, cfg=cfg)):
            resumen["paginas"] += 1
        if url:
            urls.append((url, hoy, "1.0" if clave == "inicio" else "0.8"))
    if (RAIZ / "404.html").is_file():
        _insertar(RAIZ / "404.html", _bloque("Página no encontrada | " + cfg["sitio"], cfg["descripcion"], "", "", noindex=True, cfg=cfg))
    for carpeta_ruta in sorted((RAIZ / "creadores").iterdir()):
        if not (carpeta_ruta.is_dir() and (carpeta_ruta / "datos.js").is_file() and (carpeta_ruta / "index.html").is_file()):
            continue
        carpeta = carpeta_ruta.name
        try:
            t = _leer_creador(carpeta)
        except Exception:
            continue
        nombre = str(t.get("nombre") or carpeta)
        cats = ", ".join(_categorias(t))
        desc_base = str(t.get("descripcion") or "").strip()
        plantilla = cfg["creadorDescripcion"] if desc_base else cfg["creadorSinDescripcion"]
        descripcion = _recortar(plantilla.format(nombre=nombre, descripcion=desc_base, categorias=cats, sitio=cfg["sitio"]))
        titulo = cfg["creadorTitulo"].format(nombre=nombre, sitio=cfg["sitio"], categorias=cats)
        url = base + "creadores/" + carpeta + "/" if base else ""
        imagen = img_sitio
        if base and crear_tarjeta(carpeta, t):
            imagen = base + "creadores/" + carpeta + "/compartir.jpg"
            resumen["tarjetas"] += 1
        elif base:
            f = str(t.get("foto") or "")
            if f and not f.startswith(("data:", "http")) and not f.endswith(".svg") and (carpeta_ruta / f).is_file():
                from urllib.parse import quote
                imagen = base + "creadores/" + carpeta + "/" + quote(f)
        persona = {"@context": "https://schema.org", "@type": "Person", "name": nombre, "description": descripcion, "url": url or None, "image": imagen or None,
                   "jobTitle": cats or None, "worksFor": {"@type": "Organization", "name": cfg["sitio"]},
                   "sameAs": [r.get("enlace") for r in (t.get("redes") or []) if isinstance(r, dict) and str(r.get("enlace", "")).startswith("http")]}
        persona = {k: v for k, v in persona.items() if v}
        if _insertar(carpeta_ruta / "index.html", _bloque(titulo, descripcion, url, imagen, tipo="profile", json_ld=persona, cfg=cfg)):
            resumen["creadores"] += 1
        if url:
            urls.append((url, datetime.date.fromtimestamp((carpeta_ruta / "datos.js").stat().st_mtime).isoformat(), "0.7"))
    if base:
        cuerpo = "".join("  <url><loc>%s</loc><lastmod>%s</lastmod><priority>%s</priority></url>\n" % (html.escape(u), m, pr) for u, m, pr in urls)
        (RAIZ / "sitemap.xml").write_text('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + cuerpo + "</urlset>\n", encoding="utf-8")
        (RAIZ / "robots.txt").write_text("User-agent: *\nAllow: /\n\nSitemap: %ssitemap.xml\n" % base, encoding="utf-8")
    return resumen
