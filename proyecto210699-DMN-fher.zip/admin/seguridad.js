/* Verificación en dos pasos (TOTP, compatible con Google Authenticator, Microsoft Authenticator, Authy, 2FAS...). */
(function (raiz) {
  var ABC = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  function aBase32(bytes) {
    var bits = '', out = '';
    for (var i = 0; i < bytes.length; i++) bits += bytes[i].toString(2).padStart(8, '0');
    for (var j = 0; j < bits.length; j += 5) out += ABC[parseInt(bits.slice(j, j + 5).padEnd(5, '0'), 2)];
    return out;
  }
  function deBase32(txt) {
    var bits = '', limpio = String(txt).toUpperCase().replace(/[^A-Z2-7]/g, ''), bytes = [];
    for (var i = 0; i < limpio.length; i++) bits += ABC.indexOf(limpio[i]).toString(2).padStart(5, '0');
    for (var j = 0; j + 8 <= bits.length; j += 8) bytes.push(parseInt(bits.slice(j, j + 8), 2));
    return new Uint8Array(bytes);
  }
  function nuevoSecreto() { return aBase32(crypto.getRandomValues(new Uint8Array(20))); }
  async function codigo(secreto, tiempoMs, digitos) {
    var paso = Math.floor((tiempoMs == null ? Date.now() : tiempoMs) / 30000), cont = new Uint8Array(8);
    for (var i = 7, v = paso; i >= 0; i--, v = Math.floor(v / 256)) cont[i] = v % 256;
    var clave = await crypto.subtle.importKey('raw', deBase32(secreto), { name: 'HMAC', hash: 'SHA-1' }, false, ['sign']);
    var h = new Uint8Array(await crypto.subtle.sign('HMAC', clave, cont)), o = h[h.length - 1] & 15;
    var n = ((h[o] & 127) << 24) | (h[o + 1] << 16) | (h[o + 2] << 8) | h[o + 3];
    return String(n % Math.pow(10, digitos || 6)).padStart(digitos || 6, '0');
  }
  // Acepta el código actual y el del intervalo anterior/siguiente (por si el reloj del teléfono se atrasa unos segundos).
  async function verificar(secreto, escrito, tiempoMs) {
    var c = String(escrito || '').replace(/\s+/g, ''), t = tiempoMs == null ? Date.now() : tiempoMs;
    if (!/^\d{6}$/.test(c)) return false;
    for (var d = -1; d <= 1; d++) if (await codigo(secreto, t + d * 30000) === c) return true;
    return false;
  }
  function urlOtp(secreto) { return 'otpauth://totp/Dreamers%20Nicaragua:FHerrera14?secret=' + secreto + '&issuer=Dreamers%20Nicaragua'; }
  var api = { aBase32: aBase32, deBase32: deBase32, nuevoSecreto: nuevoSecreto, codigo: codigo, verificar: verificar, urlOtp: urlOtp };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else raiz.Seguridad = api;
})(typeof window !== 'undefined' ? window : globalThis);
