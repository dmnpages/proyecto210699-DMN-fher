/* Elegir videos a mano: si la forma automática no completa 5, este panel muestra, por plataforma, los videos que SÍ se pueden mostrar. */
(function () {
  'use strict';
  var D = window.Dreamers, MAX = 5, cola = [];
  var NOMBRES = { tiktok: 'TikTok', youtube: 'YouTube', instagram: 'Instagram', twitch: 'Twitch', kick: 'Kick', facebook: 'Facebook', x: 'X' };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function red(url) { var m = D.detectarMedio(url); return m ? String(m.plataforma || '').toLowerCase() : 'otros'; }
  function miniatura(url) {
    var m = String(url).match(/(?:youtu\.be\/|v=|\/embed\/|\/shorts\/)([\w-]{11})/);
    return m ? '<img class="sl-mini" loading="lazy" alt="" src="https://i.ytimg.com/vi/' + m[1] + '/mqdefault.jpg">' : '<span class="sl-mini sl-ico">' + (D.iconoRed(red(url)) || '▶') + '</span>';
  }
  function item(url, titulo, marcado) {
    var m = D.detectarMedio(url), tipo = m && m.tipo ? ' · ' + m.tipo : '';
    return '<label class="sl-item">' + '<input type="checkbox" data-url="' + esc(url) + '"' + (marcado ? ' checked' : '') + '>' + miniatura(url) +
      '<span class="sl-txt"><b>' + esc(titulo || (NOMBRES[red(url)] || 'Enlace') + tipo) + '</b><small>' + esc(url.replace(/^https?:\/\/(www\.)?/, '').slice(0, 70)) + '</small></span>' +
      '<a href="' + esc(url) + '" target="_blank" rel="noopener" title="Abrir en una pestaña nueva">↗</a></label>';
  }
  function contar() {
    var n = document.querySelectorAll('#slLista input[data-url]:checked').length, c = document.getElementById('slCuenta');
    if (c) { c.textContent = n + ' de ' + MAX + ' elegidos'; c.className = n > MAX ? 'mal' : (n === MAX ? 'ok' : 'aviso'); }
    return n;
  }

  async function abrir(carpeta, aviso) {
    var E = window.DreamersEditor, C = window.DreamersContenido;
    var t = E.talentos().filter(function (x) { return x.carpeta === carpeta; })[0]; if (!t) return;
    var a = (await C.cargar(carpeta)) || {};
    var actuales = (a.fijados && a.fijados.length ? a.fijados : a.elegidos) || [];
    var cands = (a.candidatas || []).slice(), vistos = {};
    cands.forEach(function (c) { vistos[c.url] = 1; });
    actuales.forEach(function (u) { if (!vistos[u]) { cands.push({ red: red(u), url: u, titulo: '' }); vistos[u] = 1; } });
    var redesCreador = [];
    (t.redes || []).forEach(function (r) { var k = String((D.detectarMedio(D.enlaceRed(r)) || {}).plataforma || r.plataforma || '').toLowerCase(); if (k && redesCreador.indexOf(k) < 0) redesCreador.push(k); });
    var grupos = {}; cands.forEach(function (c) { (grupos[c.red] = grupos[c.red] || []).push(c); });
    var orden = redesCreador.concat(Object.keys(grupos).filter(function (k) { return redesCreador.indexOf(k) < 0; }));
    var html = '<div id="slEditor">' + (aviso ? '<p class="sl-aviso">' + esc(aviso) + '</p>' : '') +
      '<p class="sl-ayuda">Elige hasta ' + MAX + ' videos para el carrusel de <b>' + esc(t.nombre || carpeta) + '</b>. Solo aparecen los que sí se pueden mostrar dentro de la página; los demás ya se descartaron. Los que elijas aquí se conservan cuando actualices.</p>' +
      '<div class="sl-barra"><span id="slCuenta"></span></div><div id="slLista">' +
      orden.map(function (k) {
        var l = grupos[k] || [];
        return '<section class="sl-grupo"><h4>' + (D.iconoRed(k) || '') + ' ' + esc(NOMBRES[k] || k) + ' <small>' + l.length + ' disponible' + (l.length === 1 ? '' : 's') + '</small></h4>' +
          (l.length ? l.map(function (c) { return item(c.url, c.titulo, actuales.indexOf(c.url) >= 0); }).join('') :
            '<p class="sl-vacio">No hay videos que se puedan mostrar de esta plataforma (están restringidos o pide iniciar sesión). Prueba «Conectar mis redes» o pega un enlace abajo.</p>') + '</section>';
      }).join('') + '</div>' +
      '<div class="sl-manual"><input id="slEnlace" type="url" placeholder="Pegar un enlace de video (YouTube, TikTok, Instagram, Twitch…)"><button type="button" class="secundario" id="slAgregar">Agregar</button></div></div>';
    E.abrirModal('Elegir videos · ' + (t.nombre || carpeta), html, async function () {
      var urls = Array.prototype.map.call(document.querySelectorAll('#slLista input[data-url]:checked'), function (x) { return x.dataset.url; });
      if (urls.length > MAX) { alert('Elige máximo ' + MAX + ' videos.'); return; }
      try {
        var r = await fetch('/api/contenido/fijar', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ carpeta: carpeta, fijados: urls }) });
        var d = await r.json(); if (!r.ok || !d.ok) throw new Error(d.error || 'El servidor no respondió.');
      } catch (err) { alert('No se pudo guardar. Abre el editor con servidor_editor.py.\n' + (err.message || '')); return; }
      E.cerrarModal(); await C.pintar(); if (window.DreamersResumen) window.DreamersResumen.pintar();
      siguiente();
    });
    contar();
  }
  function siguiente() { var c = cola.shift(); if (c) abrir(c, 'Falta completar a otros creadores: se abrirá uno por uno (' + (cola.length + 1) + ' pendientes).'); }
  // Tras actualizar: abre el panel para los creadores que no llegaron a 5.
  function revisar(creadores) {
    cola = (creadores || []).filter(function (c) { return c.elegidos < MAX; }).map(function (c) { return c.carpeta; });
    if (!cola.length) return;
    var primero = cola.shift();
    abrir(primero, 'La forma automática no completó ' + MAX + ' videos. Elige tú de qué plataforma salen:');
  }

  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-ctsel]'); if (b) { cola = []; abrir(b.dataset.ctsel); return; }
    if (e.target.id === 'slAgregar') {
      var inp = document.getElementById('slEnlace'), u = (inp.value || '').trim();
      if (!/^https?:\/\//i.test(u) || !D.detectarMedio(u)) { alert('Ese enlace no se reconoce. Pega el enlace completo del video.'); return; }
      if (document.querySelector('#slLista input[data-url="' + u.replace(/"/g, '') + '"]')) { inp.value = ''; return; }
      var lista = document.getElementById('slLista'), k = red(u), g = Array.prototype.filter.call(lista.querySelectorAll('.sl-grupo'), function (s) { return s.querySelector('h4').textContent.indexOf(NOMBRES[k] || k) >= 0; })[0];
      if (!g) { g = document.createElement('section'); g.className = 'sl-grupo'; g.innerHTML = '<h4>' + esc(NOMBRES[k] || k) + '</h4>'; lista.appendChild(g); }
      var v = g.querySelector('.sl-vacio'); if (v) v.remove();
      g.insertAdjacentHTML('beforeend', item(u, '', true)); inp.value = ''; contar();
    }
  });
  document.addEventListener('change', function (e) { if (e.target.matches && e.target.matches('#slLista input[data-url]')) contar(); });
  window.DreamersSeleccion = { abrir: abrir, revisar: revisar };
})();
