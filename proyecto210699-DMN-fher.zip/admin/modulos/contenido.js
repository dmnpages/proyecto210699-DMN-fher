/* Panel "Carrusel automático": elige y muestra el contenido (5 por creador) a partir de los enlaces de redes. */
(function () {
  'use strict';
  var D = window.Dreamers, cache = {}, resultados = {}, ocupado = false;
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  // Lee creadores/<carpeta>/auto.js (si existe) sin guardar en caché del navegador.
  function cargar(carpeta) {
    return new Promise(function (ok) {
      delete D.auto[carpeta];
      var s = document.createElement('script');
      s.src = '../creadores/' + encodeURIComponent(carpeta) + '/auto.js?v=' + Date.now();
      s.onload = function () { s.remove(); ok(D.auto[carpeta] || null); };
      s.onerror = function () { s.remove(); ok(null); };
      document.head.appendChild(s);
    });
  }
  async function cargarTodos(ts) {
    await Promise.all((ts || []).map(async function (t) { cache[t.carpeta] = await cargar(t.carpeta); }));
    return cache;
  }
  function etiqueta(url) {
    var m = D.detectarMedio(url);
    return m ? (m.plataforma + (m.tipo ? ' · ' + m.tipo : '')) : 'Enlace';
  }
  function icono(url) { var m = D.detectarMedio(url); return m ? D.iconoRed(m.plataforma) : ''; }

  function fila(t, i) {
    var a = cache[t.carpeta], redes = (t.redes || []).filter(function (r) { return D.enlaceRed(r); });
    var res = resultados[t.carpeta], estado, clase = '';
    if (!redes.length) { estado = 'Sin enlaces de redes'; clase = 'mal'; }
    else if (!a || !(a.elegidos || []).length) { estado = 'Sin contenido todavía'; clase = 'mal'; }
    else { estado = a.elegidos.length + ' en el carrusel · ' + (a.reserva || []).length + ' de reserva · ' + esc(a.actualizado || ''); clase = a.elegidos.length >= 5 ? 'ok' : 'aviso'; }
    var lista = a && a.elegidos && a.elegidos.length ?
      '<ol class="ct-lista">' + a.elegidos.map(function (u) { return '<li>' + icono(u) + '<span>' + esc(etiqueta(u)) + '</span><a href="' + esc(u) + '" target="_blank" rel="noopener">Abrir ↗</a></li>'; }).join('') + '</ol>' : '';
    var detalle = res ? '<p class="ct-res">' + res.map(function (r) { return esc(r.red) + ': ' + r.validas + ' válidas de ' + r.encontradas + (r.restringidas ? ' (' + r.restringidas + ' restringidas, descartadas)' : ''); }).join(' · ') + '</p>' : '';
    return '<article class="ct-fila"><div class="ct-avatar">' + esc((t.nombre || '?').charAt(0).toUpperCase()) + '</div>' +
      '<div class="ct-info"><h3>' + esc(t.nombre || t.carpeta) + '</h3><p class="ct-estado ' + clase + '">' + estado + '</p>' + detalle +
      (lista ? '<details><summary>Ver contenido elegido</summary>' + lista + '</details>' : '') + '</div>' +
      '<div class="ct-redes">' + redes.map(function (r) { return '<span title="' + esc(r.plataforma) + '">' + D.iconoRed(r.plataforma) + '</span>'; }).join('') + '</div>' +
      '<div class="ct-botones"><button class="secundario" data-ct="' + i + '"' + (redes.length ? '' : ' disabled') + '>⟳ Actualizar</button>' +
      '<button class="secundario" data-ctsel="' + esc(t.carpeta) + '"' + (redes.length ? '' : ' disabled') + '>▣ Elegir videos</button></div></article>';
  }

  async function pintar() {
    var raiz = document.getElementById('contenidoAuto');
    if (!raiz || !window.DreamersEditor) return;
    var ts = window.DreamersEditor.talentos();
    await cargarTodos(ts);
    raiz.innerHTML = '<div class="toolbar"><div><h2>Contenido de cada creador</h2><p>La página muestra 5 contenidos por creador en un carrusel. Se eligen solos a partir de sus enlaces de redes y se descartan los que no se pueden mostrar dentro de la página.</p></div>' +
      '<div class="toolbar-botones"><button id="ctTodos">▶ Actualizar todos</button></div></div>' +
      '<div class="ct-aviso">Tarda un poco: abre cada red, busca publicaciones recientes y comprueba una por una que se puedan insertar. Si guardaste sesión con «Conectar mis redes», también lee Instagram y otras redes que piden iniciar sesión. Después sube los cambios a GitHub.</div>' +
      '<div class="ct-lista-creadores">' + ts.map(fila).join('') + '</div>';
  }

  async function actualizar(indices, boton, opciones) {
    var silencioso = !!(opciones && opciones.silencioso), salidaD = null;
    if (ocupado) return null;
    ocupado = true;
    var ts = window.DreamersEditor.talentos();
    var pedido = indices.map(function (i) { var t = ts[i]; return { carpeta: t.carpeta, redes: (t.redes || []).map(function (r) { return { plataforma: r.plataforma, enlace: D.enlaceRed(r) }; }).filter(function (r) { return r.enlace; }) }; });
    var textoOriginal = boton && boton.textContent;
    document.querySelectorAll('#contenidoAuto button').forEach(function (b) { b.disabled = true; });
    if (boton) boton.textContent = 'Buscando contenido…';
    try {
      // Guarda primero, para que las carpetas de creadores nuevos existan en el disco.
      await window.DreamersEditor.guardar();
      var r = await fetch('/api/contenido', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ creadores: pedido }) });
      var d = await r.json();
      if (!r.ok || !d.ok) throw new Error(d.error || 'El servidor no respondió.');
      salidaD = d;
      d.creadores.forEach(function (c) { resultados[c.carpeta] = c.resumen; });
      var faltan = d.creadores.filter(function (c) { return c.elegidos < 5; }).map(function (c) { return c.carpeta + ' (' + c.elegidos + ')'; });
      await pintar();
      var e = document.getElementById('estado');
      if (e) { e.textContent = 'Contenido actualizado (' + d.modo + '). ' + (faltan.length ? 'Con menos de 5: ' + faltan.join(', ') : 'Todos con 5.'); }
    } catch (err) {
      console.error(err);
      if (!silencioso) alert('No se pudo actualizar el contenido. Abre el editor con servidor_editor.py.\n' + (err.message || ''));
      else { var e2 = document.getElementById('estado'); if (e2) e2.textContent = 'No se pudo actualizar el contenido.'; }
    }
    ocupado = false;
    await pintar();
    if (!silencioso && salidaD && window.DreamersSeleccion) window.DreamersSeleccion.revisar(salidaD.creadores);
    return salidaD;
  }

  document.addEventListener('click', function (e) {
    if (e.target.id === 'ctTodos') actualizar(window.DreamersEditor.talentos().map(function (_, i) { return i; }), e.target);
    var b = e.target.closest('[data-ct]'); if (b) actualizar([+b.dataset.ct], b);
  });
  document.addEventListener('dreamers:panel', function (e) { if (e.detail === 'contenido') pintar(); });
  window.DreamersContenido = { cargarTodos: cargarTodos, pintar: pintar, cargar: cargar, actualizar: actualizar };
})();
