/* "Traer fotos": si un creador no tiene foto, descarga la de su perfil en redes y la deja como su foto. */
(function () {
  'use strict';
  var D = window.Dreamers, ocupado = false;

  async function sinFoto(t) {
    var f = String(t.foto || '').trim();
    if (!f || f === 'foto.svg') return true;
    if (/^(data:|https?:)/.test(f)) return false;
    try { var r = await fetch('../creadores/' + encodeURIComponent(t.carpeta) + '/' + encodeURIComponent(f), { method: 'HEAD', cache: 'no-store' }); return !r.ok; }
    catch (e) { return false; }
  }
  async function traer() {
    if (ocupado || !window.DreamersEditor) return;
    var E = window.DreamersEditor, ts = E.talentos(), boton = document.getElementById('traerFotos'), msg = document.getElementById('estado');
    ocupado = true; var original = boton && boton.textContent; if (boton) { boton.disabled = true; boton.textContent = 'Buscando fotos…'; }
    try {
      var faltan = [];
      for (var i = 0; i < ts.length; i++) {
        if (ts[i]._origen && await sinFoto(ts[i]) && (ts[i].redes || []).some(function (r) { return D.enlaceRed(r); })) faltan.push(ts[i]);
      }
      if (!faltan.length) { if (msg) msg.textContent = 'Todos los creadores ya tienen foto.'; return; }
      var pedido = faltan.map(function (t) { return { carpeta: t.carpeta, redes: (t.redes || []).map(function (r) { return { plataforma: r.plataforma, enlace: D.enlaceRed(r) }; }).filter(function (r) { return r.enlace; }) }; });
      var r = await fetch('/api/fotos', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ creadores: pedido }) });
      var d = await r.json();
      if (!r.ok || !d.ok) throw new Error(d.error || 'El servidor no respondió.');
      var puestas = [], sin = [];
      d.creadores.forEach(function (c) {
        var t = ts.filter(function (x) { return x.carpeta === c.carpeta; })[0];
        if (c.ok && t) { t.foto = c.archivo; t.posicionFoto = '50% 50%'; t.fotoZoom = 1; puestas.push((t.nombre || t.carpeta) + ' (' + c.red + ')'); }
        else if (t) sin.push(t.nombre || t.carpeta);
      });
      if (puestas.length) { await E.guardar(); E.pintar(); }
      var texto = (puestas.length ? 'Fotos puestas: ' + puestas.join(', ') + '. ' : '') + (sin.length ? 'No se pudo en: ' + sin.join(', ') + ' (prueba «Conectar mis redes» o sube la foto a mano).' : '');
      if (msg) { msg.textContent = texto; clearTimeout(msg._t); msg._t = setTimeout(function () { msg.textContent = ''; }, 12000); }
      if (window.DreamersResumen) window.DreamersResumen.pintar();
    } catch (err) {
      console.error(err); alert('No se pudieron traer las fotos. Abre el editor con servidor_editor.py.\n' + (err.message || ''));
    } finally { ocupado = false; if (boton) { boton.disabled = false; boton.textContent = original; } }
  }
  document.addEventListener('click', function (e) { if (e.target.id === 'traerFotos') traer(); });
  window.DreamersFotos = { sinFoto: sinFoto, traer: traer };
})();
