/* Panel "Resumen": cifras de la agencia, avisos y accesos rápidos. */
(function () {
  'use strict';
  var D = window.Dreamers;
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  async function pintar() {
    var raiz = document.getElementById('resumen');
    if (!raiz || !window.DreamersEditor) return;
    var ts = window.DreamersEditor.talentos();
    var enlaces = 0, total = 0;
    ts.forEach(function (t) {
      (t.redes || []).forEach(function (r) { if (D.enlaceRed(r)) enlaces++; });
      var n = D.numSeguidores(t.seguidores); if (n !== null) total += n;
    });
    var auto = window.DreamersContenido ? await window.DreamersContenido.cargarTodos(ts) : {};
    var conCarrusel = ts.filter(function (t) { var a = auto[t.carpeta]; return a && a.elegidos && a.elegidos.length; }).length;

    var sinFotos = {};
    if (window.DreamersFotos) await Promise.all(ts.map(async function (t) { if (t._origen) sinFotos[t.carpeta] = await window.DreamersFotos.sinFoto(t); }));
    var avisos = [];
    ts.forEach(function (t) {
      var nom = t.nombre || t.carpeta;
      if (!(t.redes || []).some(function (r) { return D.enlaceRed(r); })) avisos.push([nom, 'No tiene enlaces de redes: no se puede calcular el total ni elegir contenido.']);
      var a = auto[t.carpeta];
      if (!a || !(a.elegidos || []).length) avisos.push([nom, 'Sin contenido automático. Entra a «Carrusel» y pulsa Actualizar.']);
      else if (a.elegidos.length < 5) avisos.push([nom, 'Solo se encontraron ' + a.elegidos.length + ' contenidos que se puedan mostrar.']);
      else if (a.actualizado && (Date.now() - new Date(a.actualizado).getTime()) > 14 * 864e5) avisos.push([nom, 'El carrusel tiene más de 14 días (' + a.actualizado + ').']);
      if (!String(t.descripcion || '').trim()) avisos.push([nom, 'Falta la descripción.']);
      if (sinFotos[t.carpeta]) avisos.push([nom, 'No tiene foto. Usa «Traer fotos faltantes» o súbela en Creadores.']);
    });
    var top = ts.slice().map(function (t) { return { t: t, n: D.numSeguidores(t.seguidores) || 0 }; }).sort(function (a, b) { return b.n - a.n; }).slice(0, 5);
    var max = top.length && top[0].n ? top[0].n : 1;

    raiz.innerHTML =
      '<div class="rs-cifras">' +
      '<div class="rs-cifra"><b>' + ts.length + '</b><span>Creadores</span></div>' +
      '<div class="rs-cifra"><b>' + esc(D.formatoSeguidores(total) || '0') + '</b><span>Seguidores sumados</span></div>' +
      '<div class="rs-cifra"><b>' + enlaces + '</b><span>Enlaces de redes</span></div>' +
      '<div class="rs-cifra ' + (conCarrusel === ts.length ? 'ok' : 'aviso') + '"><b>' + conCarrusel + '/' + ts.length + '</b><span>Con carrusel automático</span></div></div>' +
      '<div class="rs-cols"><section class="rs-caja"><h3>Accesos rápidos</h3><div class="rs-acciones">' +
      '<button data-rs="agregarTalento">＋ Agregar creador</button>' +
      '<button data-rs="actualizarTodo">⚡ Actualizar todo</button>' +
      '<button class="secundario" data-rs="actualizarSeguidores">⟳ Actualizar seguidores</button>' +
      '<button class="secundario" data-rs="contenido">▶ Actualizar carrusel</button>' +
      '<button class="secundario" data-rs="traerFotos">🖼 Traer fotos faltantes</button>' +
      '<button class="secundario" data-rs="revisarOrtografia">✓ Revisar ortografía</button>' +
      '<button class="secundario" data-rs="verSitio">↗ Ver sitio</button></div>' +
      '<p class="rs-nota">Cada semana: «Actualizar seguidores» y «Actualizar carrusel», luego sube los cambios a GitHub.</p></section>' +
      '<section class="rs-caja"><h3>Más seguidores</h3>' + (top.map(function (x) {
        return '<div class="rs-barra"><span>' + esc(x.t.nombre || x.t.carpeta) + '</span><i style="--w:' + Math.max(4, Math.round(x.n / max * 100)) + '%"></i><b>' + esc(D.formatoSeguidores(x.n) || '0') + '</b></div>';
      }).join('') || '<p class="rs-nota">Aún no hay datos.</p>') + '</section></div>' +
      '<section class="rs-caja"><h3>Pendientes <small>' + avisos.length + '</small></h3>' + (avisos.length ?
        '<ul class="rs-avisos">' + avisos.slice(0, 12).map(function (a) { return '<li><b>' + esc(a[0]) + '</b> ' + esc(a[1]) + '</li>'; }).join('') + (avisos.length > 12 ? '<li>… y ' + (avisos.length - 12) + ' más.</li>' : '') + '</ul>' :
        '<p class="rs-nota">✓ Todo en orden.</p>') + '</section>';
  }

  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-rs]'); if (!b) return;
    var k = b.dataset.rs;
    if (k === 'contenido') { window.DreamersNav.ir('contenido'); return; }
    var real = document.getElementById(k); if (real) real.click();
  });
  document.addEventListener('dreamers:panel', function (e) { if (e.detail === 'resumen') pintar(); });
  window.DreamersResumen = { pintar: pintar };
  // Primera vez: cuando el editor ya cargó los datos
  var intentos = 0, t = setInterval(function () {
    if ((window.DreamersEditor && window.DreamersEditor.talentos().length) || ++intentos > 40) { clearInterval(t); pintar(); }
  }, 250);
})();
