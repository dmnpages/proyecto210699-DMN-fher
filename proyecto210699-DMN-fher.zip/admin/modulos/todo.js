/* «Actualizar todo»: seguidores → carrusel → fotos faltantes, en orden. Los botones individuales siguen existiendo. */
(function () {
  'use strict';
  var corriendo = false;
  function msg(t) { var e = document.getElementById('estado'); if (e) { e.textContent = t; clearTimeout(e._t); } }
  async function todo() {
    var E = window.DreamersEditor, C = window.DreamersContenido, F = window.DreamersFotos;
    if (corriendo || !E) return;
    if (!E.talentos().length) { alert('Aún no hay creadores.'); return; }
    corriendo = true;
    var boton = document.getElementById('actualizarTodo'), original = boton && boton.textContent, partes = [], pendientes = [];
    document.querySelectorAll('.toolbar-botones button, #contenidoAuto button, .rs-acciones button').forEach(function (b) { b.dataset.prevDis = b.disabled ? '1' : ''; b.disabled = true; });
    function paso(n, t) { if (boton) boton.textContent = '⏳ ' + n + '/3 ' + t; msg('Actualizar todo: ' + n + '/3 · ' + t + '…'); }
    try {
      paso(1, 'Seguidores');
      var s = await E.actualizarSeguidores({ silencioso: true });
      partes.push(s ? 'Seguidores: ' + s.ok + ' de ' + s.total + (s.fallos.length ? ' (' + s.fallos.length + ' sin leer, se conservó el número anterior)' : '') : 'Seguidores: sin enlaces');
      document.querySelectorAll('.toolbar-botones button').forEach(function (b) { b.disabled = true; });
      paso(2, 'Carrusel');
      var c = await C.actualizar(E.talentos().map(function (_, i) { return i; }), null, { silencioso: true });
      if (c) { pendientes = c.creadores.filter(function (x) { return x.elegidos < 5; }); partes.push('Carrusel: ' + (c.creadores.length - pendientes.length) + ' de ' + c.creadores.length + ' completos'); }
      else partes.push('Carrusel: no se pudo');
      paso(3, 'Fotos');
      await F.traer();
      partes.push('Fotos revisadas');
    } catch (err) { console.error(err); partes.push('Se detuvo por un error: ' + (err.message || err)); }
    corriendo = false;
    document.querySelectorAll('.toolbar-botones button, #contenidoAuto button, .rs-acciones button').forEach(function (b) { b.disabled = !!b.dataset.prevDis; delete b.dataset.prevDis; });
    if (boton) boton.textContent = original;
    msg('Listo. ' + partes.join(' · '));
    if (window.DreamersResumen) window.DreamersResumen.pintar();
    if (pendientes.length && window.DreamersSeleccion) window.DreamersSeleccion.revisar(pendientes);
  }
  document.addEventListener('click', function (e) { if (e.target.id === 'actualizarTodo') todo(); });
})();
