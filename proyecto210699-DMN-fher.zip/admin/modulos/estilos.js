/* Estilo propio por texto: muestra u oculta los controles (color, tamaño, negrita) de cada campo. */
(function () {
  'use strict';
  document.addEventListener('change', function (e) {
    var on = e.target.closest && e.target.matches('[data-e-on]') ? e.target : null;
    if (!on) return;
    var ctl = on.closest('.estilo-ctl'), op = ctl.querySelector('.estilo-op');
    op.hidden = !on.checked;
    if (on.checked && !ctl.querySelector('[data-e-usar]').checked && !+ctl.querySelector('[data-e-tam]').value !== 1) { /* el usuario elige qué activar */ }
  });
  // Al tocar el selector de color se activa «color» automáticamente.
  document.addEventListener('input', function (e) {
    if (e.target.matches && e.target.matches('[data-e-color]')) e.target.closest('.estilo-ctl').querySelector('[data-e-usar]').checked = true;
  });
})();
