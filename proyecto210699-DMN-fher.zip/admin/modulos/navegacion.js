/* Navegación del panel: menú lateral (PC/tablet) y barra inferior (teléfono). Cada sección es independiente. */
(function () {
  'use strict';
  var TITULOS = { resumen: 'Resumen', talentos: 'Creadores', contenido: 'Carrusel automático', paginas: 'Páginas', buscadores: 'Buscadores y compartir', apariencia: 'Apariencia' };
  var PANELES = { resumen: 'panelResumen', talentos: 'panelTalentos', contenido: 'panelContenido', paginas: 'panelPaginas', buscadores: 'panelBuscadores', apariencia: 'panelApariencia' };
  var CLAVE = 'dreamers-admin-panel';

  function ir(k) {
    if (!PANELES[k]) k = 'resumen';
    Object.keys(PANELES).forEach(function (p) { var el = document.getElementById(PANELES[p]); if (el) el.hidden = p !== k; });
    document.querySelectorAll('.tab[data-tab]').forEach(function (t) { t.classList.toggle('activo', t.dataset.tab === k); t.setAttribute('aria-current', t.dataset.tab === k ? 'page' : 'false'); });
    var h = document.getElementById('tituloPanel'); if (h) h.textContent = TITULOS[k];
    try { sessionStorage.setItem(CLAVE, k); } catch (e) {}
    var mas = document.querySelector('.mas'); if (mas) mas.open = false;
    window.scrollTo(0, 0);
    document.dispatchEvent(new CustomEvent('dreamers:panel', { detail: k }));
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest('.tab[data-tab]'); if (b) ir(b.dataset.tab);
    var mas = document.querySelector('.mas'); if (mas && mas.open && !e.target.closest('.mas')) mas.open = false;
  });
  window.DreamersNav = { ir: ir };
  var inicial = 'resumen'; try { inicial = sessionStorage.getItem(CLAVE) || 'resumen'; } catch (e) {}
  ir(inicial);
})();
