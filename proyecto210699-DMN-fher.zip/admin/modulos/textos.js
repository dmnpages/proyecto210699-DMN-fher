/* Textos extra: bloques de texto adicionales (con su propio color) que se pueden poner en cualquier página. */
(function () {
  'use strict';
  var PAGINAS = [['inicio', 'Inicio'], ['talentos', 'Lista de creadores'], ['nosotros', 'Nosotros'], ['contacto', 'Contacto']];
  var DESPUES = {
    inicio: [['encabezado', 'Al principio (debajo del menú)'], ['portada', 'Después de la portada'], ['talentos', 'Después de los creadores'], ['clientes', 'Después de los clientes'], ['final', 'Al final (antes del pie)']],
    talentos: [['encabezado', 'Al principio (debajo del menú)'], ['talentos', 'Después de la lista de creadores'], ['final', 'Al final (antes del pie)']],
    nosotros: [['encabezado', 'Al principio (debajo del menú)'], ['nosotros', 'Después de «Sobre nosotros»'], ['final', 'Al final (antes del pie)']],
    contacto: [['encabezado', 'Al principio (debajo del menú)'], ['contacto', 'Después del formulario'], ['final', 'Al final (antes del pie)']]
  };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function opts(lista, actual) { return lista.map(function (o) { return '<option value="' + o[0] + '"' + (o[0] === actual ? ' selected' : '') + '>' + o[1] + '</option>'; }).join(''); }
  function color(clave, etiqueta, valor) {
    return '<span class="tx-color" data-c="' + clave + '"><label class="chk"><input type="checkbox" data-usar' + (valor ? ' checked' : '') + '> ' + etiqueta + '</label><input type="color" data-valor value="' + (valor || '#ffffff') + '"></span>';
  }
  function bloque(b, i) {
    b = b || {};
    var pag = b.pagina || 'inicio';
    return '<article class="tx-bloque" data-i="' + i + '"><header><b>Bloque <span class="tx-n">' + (i + 1) + '</span></b>' +
      '<label class="chk"><input type="checkbox" data-k="visible"' + (b.visible === false ? '' : ' checked') + '> Visible</label>' +
      '<span class="tx-mover"><button type="button" data-tx="sube" title="Subir">↑</button><button type="button" data-tx="baja" title="Bajar">↓</button><button type="button" class="danger" data-tx="borra" title="Eliminar">Eliminar</button></span></header>' +
      '<div class="tx-fila"><label>Página<select data-k="pagina">' + opts(PAGINAS, pag) + '</select></label>' +
      '<label>Dónde va<select data-k="despuesDe">' + opts(DESPUES[pag], b.despuesDe || 'final') + '</select></label></div>' +
      '<label>Título (opcional)<input data-k="titulo" value="' + esc(b.titulo) + '"></label>' +
      '<label>Texto <small>(deja una línea vacía para separar párrafos)</small><textarea data-k="texto" rows="6">' + esc(b.texto) + '</textarea></label>' +
      '<div class="tx-fila"><label>Alineación<select data-k="alineacion">' + opts([['izquierda', 'Izquierda'], ['centro', 'Centro'], ['derecha', 'Derecha']], b.alineacion || 'izquierda') + '</select></label>' +
      '<label>Tamaño del texto<select data-k="tamano">' + opts([['pequeno', 'Pequeño'], ['medio', 'Normal'], ['grande', 'Grande'], ['enorme', 'Muy grande']], b.tamano || 'medio') + '</select></label>' +
      '<label>Ancho<select data-k="ancho">' + opts([['normal', 'Normal'], ['angosto', 'Angosto'], ['ancho', 'Ancho']], b.ancho || 'normal') + '</select></label></div>' +
      '<div class="tx-fila"><label>Fondo<select data-k="fondo">' + opts([['', 'Sin fondo (el de la página)'], ['blanco', 'Blanco'], ['gris', 'Gris claro'], ['oscuro', 'Oscuro'], ['color', 'Color propio…']], b.fondo || '') + '</select></label>' +
      '<span class="tx-color" data-c="colorFondo"' + (b.fondo === 'color' ? '' : ' hidden') + '><input type="color" data-valor value="' + (b.colorFondo || '#0b1426') + '"></span></div>' +
      '<div class="tx-fila tx-colores">' + color('colorTitulo', 'Color del título', b.colorTitulo) + color('colorTexto', 'Color del texto', b.colorTexto) + '</div></article>';
  }
  function pintar(lista) {
    return '<div id="txEditor"><p class="tx-ayuda">Cada bloque es un título y un texto que aparece en la página que elijas, con su propio color. Los colores de aquí son independientes de «Apariencia».</p>' +
      '<div id="txLista">' + lista.map(bloque).join('') + '</div><button type="button" class="mini-add" id="txAgregar">＋ Agregar bloque de texto</button></div>';
  }
  function leer() {
    return Array.prototype.map.call(document.querySelectorAll('#txLista .tx-bloque'), function (a) {
      var o = {};
      a.querySelectorAll('[data-k]').forEach(function (x) { o[x.dataset.k] = x.type === 'checkbox' ? x.checked : x.value; });
      a.querySelectorAll('.tx-color[data-c]').forEach(function (c) {
        var u = c.querySelector('[data-usar]'), v = c.querySelector('[data-valor]');
        if (c.dataset.c === 'colorFondo') { if (o.fondo === 'color') o.colorFondo = v.value; }
        else if (u && u.checked) o[c.dataset.c] = v.value;
      });
      if (o.fondo !== 'color') delete o.colorFondo;
      return o;
    }).filter(function (b) { return String(b.titulo || '').trim() || String(b.texto || '').trim(); });
  }
  function renumerar() { document.querySelectorAll('#txLista .tx-bloque').forEach(function (a, i) { a.dataset.i = i; a.querySelector('.tx-n').textContent = i + 1; }); }

  function abrir() {
    var E = window.DreamersEditor, actual = (E.contenidos().textos || {}).bloques || [];
    E.abrirModal('Textos extra', pintar(actual), function () {
      E.contenidos().textos = { bloques: leer() };
      E.guardar(); E.cerrarModal();
    });
  }
  // Se intercepta «Editar» de la tarjeta «Textos extra» (antes que el editor genérico de secciones)
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-page="textos"]');
    if (b) { e.stopImmediatePropagation(); e.preventDefault(); abrir(); return; }
    var m = e.target.closest && e.target.closest('[data-tx]'); if (!m) return;
    var a = m.closest('.tx-bloque'), lista = document.getElementById('txLista');
    if (m.dataset.tx === 'borra') { if (confirm('¿Eliminar este bloque de texto?')) a.remove(); }
    if (m.dataset.tx === 'sube' && a.previousElementSibling) lista.insertBefore(a, a.previousElementSibling);
    if (m.dataset.tx === 'baja' && a.nextElementSibling) lista.insertBefore(a.nextElementSibling, a);
    renumerar();
  }, true);
  document.addEventListener('click', function (e) {
    if (e.target.id !== 'txAgregar') return;
    var lista = document.getElementById('txLista'); lista.insertAdjacentHTML('beforeend', bloque({ pagina: 'inicio', despuesDe: 'final' }, lista.children.length));
    lista.lastElementChild.querySelector('[data-k=titulo]').focus(); renumerar();
  });
  document.addEventListener('change', function (e) {
    var a = e.target.closest && e.target.closest('.tx-bloque'); if (!a) return;
    if (e.target.dataset.k === 'pagina') { a.querySelector('[data-k=despuesDe]').innerHTML = opts(DESPUES[e.target.value], 'final'); }
    if (e.target.dataset.k === 'fondo') { a.querySelector('.tx-color[data-c=colorFondo]').hidden = e.target.value !== 'color'; }
  });
  document.addEventListener('input', function (e) {
    if (e.target.matches && e.target.matches('.tx-color [data-valor]')) { var u = e.target.closest('.tx-color').querySelector('[data-usar]'); if (u) u.checked = true; }
  });
})();
