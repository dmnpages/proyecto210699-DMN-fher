/* Panel "Buscadores": textos para Google y para la vista previa al compartir (WhatsApp, Facebook, X...). */
(function () {
  'use strict';
  var cfg = null, dominio = null, ocupado = false;
  var PAGINAS = [['inicio', 'Inicio'], ['creadores', 'Lista de creadores'], ['nosotros', 'Nosotros'], ['contacto', 'Contacto']];
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function llamar(ruta, cuerpo) { return fetch(ruta, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(cuerpo || {}) }).then(function (r) { return r.json(); }); }

  function campo(id, etiqueta, valor, max, area) {
    var ctl = area ? '<textarea id="' + id + '" rows="2" maxlength="300">' + esc(valor) + '</textarea>' : '<input id="' + id + '" maxlength="300" value="' + esc(valor) + '">';
    return '<label>' + etiqueta + ctl + (max ? '<small class="sq-cuenta" data-max="' + max + '" data-de="' + id + '"></small>' : '') + '</label>';
  }
  function cuentas(raiz) {
    raiz.querySelectorAll('.sq-cuenta').forEach(function (c) {
      var el = document.getElementById(c.dataset.de), n = el ? el.value.length : 0, max = +c.dataset.max;
      c.textContent = n + ' / ' + max + (n > max ? ' — Google lo recortará' : '');
      c.classList.toggle('pasado', n > max);
    });
  }
  function vista(raiz) {
    var k = (raiz.querySelector('#sqVerPagina') || {}).value || 'inicio';
    var t = (document.getElementById('sq_t_' + k) || {}).value || '', d = (document.getElementById('sq_d_' + k) || {}).value || '';
    var host = dominio || 'tu-dominio.com', ruta = k === 'inicio' ? '' : k + '/';
    raiz.querySelector('#sqGoogle').innerHTML = '<span class="g-url">' + esc(host + (ruta ? ' › ' + ruta.replace('/', '') : '')) + '</span><b class="g-tit">' + esc(t.slice(0, 62)) + '</b><span class="g-des">' + esc(d.slice(0, 158)) + '</span>';
    raiz.querySelector('#sqCompartir').innerHTML = '<img src="../assets/img/compartir.jpg" alt=""><div><small>' + esc(host.toUpperCase()) + '</small><b>' + esc(t) + '</b><span>' + esc(d.slice(0, 110)) + '</span></div>';
  }

  async function pintar() {
    var raiz = document.getElementById('buscadores'); if (!raiz) return;
    raiz.innerHTML = '<p>Cargando…</p>';
    var r;
    try { r = await llamar('/api/seo/leer'); } catch (e) { raiz.innerHTML = '<p class="error">Abre el editor con servidor_editor.py.</p>'; return; }
    if (!r.ok) { raiz.innerHTML = '<p class="error">' + esc(r.error) + '</p>'; return; }
    cfg = r.config; dominio = r.dominio;
    var pag = PAGINAS.map(function (p) {
      return '<section class="sq-caja"><h3>' + p[1] + '</h3>' + campo('sq_t_' + p[0], 'Título (lo que se ve en Google y al compartir)', cfg.paginas[p[0]].titulo, 60) + campo('sq_d_' + p[0], 'Descripción', cfg.paginas[p[0]].descripcion, 160, true) + '</section>';
    }).join('');
    raiz.innerHTML = '<div class="toolbar"><div><h2>Buscadores y vista previa al compartir</h2><p>Lo que aparece en Google y en la tarjeta que se muestra al pegar un enlace en WhatsApp, Facebook, Instagram o X. Se actualiza solo cada vez que guardas.</p></div><div class="toolbar-botones"><button id="sqGuardar">Guardar y aplicar</button></div></div>' +
      (dominio ? '<div class="ct-aviso">Dominio detectado (archivo CNAME): <b>' + esc(dominio) + '</b>. Cada creador tiene su propia imagen de vista previa (foto, nombre, categorías y seguidores), creada automáticamente.</div>' : '<div class="ct-aviso aviso-mal">No hay archivo CNAME: sin dominio no se pueden generar los enlaces completos de la vista previa.</div>') +
      '<div class="sq-layout"><div class="sq-form">' +
      '<section class="sq-caja"><h3>Sitio</h3>' + campo('sq_sitio', 'Nombre del sitio', cfg.sitio) + campo('sq_desc', 'Descripción general', cfg.descripcion, 160, true) + '</section>' + pag +
      '<section class="sq-caja"><h3>Páginas de creadores</h3><p class="sq-ayuda">Puedes usar <code>{nombre}</code>, <code>{sitio}</code>, <code>{categorias}</code> y <code>{descripcion}</code>.</p>' +
      campo('sq_ct', 'Título', cfg.creadorTitulo) + campo('sq_cd', 'Descripción (si el creador tiene descripción)', cfg.creadorDescripcion, 0, true) + campo('sq_cs', 'Descripción (si no tiene)', cfg.creadorSinDescripcion, 0, true) + '</section></div>' +
      '<aside class="sq-vista"><h3>Vista previa</h3><label>Página<select id="sqVerPagina">' + PAGINAS.map(function (p) { return '<option value="' + p[0] + '">' + p[1] + '</option>'; }).join('') + '</select></label>' +
      '<p class="sq-etq">En Google</p><div id="sqGoogle" class="sq-google"></div><p class="sq-etq">Al compartir el enlace</p><div id="sqCompartir" class="sq-tarjeta"></div></aside></div><p id="sqEstado" class="sq-estado" role="status"></p>';
    cuentas(raiz); vista(raiz);
  }
  async function guardar() {
    if (ocupado) return; ocupado = true;
    var raiz = document.getElementById('buscadores'), est = document.getElementById('sqEstado'), g = function (id) { return document.getElementById(id).value; };
    var datos = { sitio: g('sq_sitio'), descripcion: g('sq_desc'), creadorTitulo: g('sq_ct'), creadorDescripcion: g('sq_cd'), creadorSinDescripcion: g('sq_cs'), paginas: {} };
    PAGINAS.forEach(function (p) { datos.paginas[p[0]] = { titulo: g('sq_t_' + p[0]), descripcion: g('sq_d_' + p[0]) }; });
    est.textContent = 'Aplicando a todas las páginas…';
    try {
      var r = await llamar('/api/seo/guardar', datos);
      est.textContent = r.ok ? '✓ Listo: ' + r.resumen.paginas + ' páginas y ' + r.resumen.creadores + ' creadores actualizados (' + r.resumen.tarjetas + ' con imagen propia).' : '⚠ ' + (r.error || 'No se pudo guardar.');
    } catch (e) { est.textContent = '⚠ No se pudo contactar al servidor del editor.'; }
    ocupado = false;
  }
  document.addEventListener('input', function (e) { var raiz = document.getElementById('buscadores'); if (raiz && raiz.contains(e.target)) { cuentas(raiz); vista(raiz); } });
  document.addEventListener('change', function (e) { if (e.target.id === 'sqVerPagina') vista(document.getElementById('buscadores')); });
  document.addEventListener('click', function (e) { if (e.target.id === 'sqGuardar') guardar(); });
  document.addEventListener('dreamers:panel', function (e) { if (e.detail === 'buscadores') pintar(); });
})();
