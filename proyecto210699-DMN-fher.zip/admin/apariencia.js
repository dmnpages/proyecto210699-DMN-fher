/* Apariencia del sitio: colores, letras y fondos. Genera config/tema.css (que cargan todas las páginas) y config/tema.json (lo que ves aquí). */
(function (raiz) {
  var COLORES = [
    { k: '--blue', n: 'Color principal', ayuda: 'Botones, líneas y detalles', d: '#2ea3f2' },
    { k: '--orange', n: 'Color secundario', ayuda: 'Viñetas, detalles y enfoque', d: '#f5903b' },
    { k: '--black', n: 'Menú y pie de página', ayuda: 'Fondo de la barra superior y del pie', d: '#000000' },
    { k: '--navy', n: 'Fondo oscuro de secciones', ayuda: 'Portada, contacto y perfil', d: '#0b1426' },
    { k: '--ink', n: 'Fondo general', ayuda: 'Detrás de todo el sitio', d: '#070a12' },
    { k: '--white', n: 'Blanco', ayuda: 'Secciones claras y letras sobre fondos oscuros', d: '#ffffff' },
    { k: '--grey', n: 'Gris de secciones claras', ayuda: 'Clientes y recuadros', d: '#f0f0f0' },
    { k: '--head', n: 'Títulos sobre fondo claro', ayuda: '', d: '#333333' },
    { k: '--text', n: 'Texto normal', ayuda: '', d: '#666666' }
  ];
  var TITULOS = ['Audiowide', 'Orbitron', 'Oswald', 'Bebas Neue', 'Anton', 'Montserrat', 'Poppins', 'Rajdhani', 'Playfair Display', 'Russo One'];
  var TEXTOS = ['Noto Sans', 'Inter', 'Roboto', 'Open Sans', 'Lato', 'Poppins', 'Montserrat'];
  var AREAS = [
    { k: 'sitio', n: 'Fondo general del sitio', sel: 'body', texto: false },
    { k: 'encabezado', n: 'Menú (barra superior)', sel: '.hdr', texto: false },
    { k: 'portada', n: 'Portada', sel: '.hero', texto: true },
    { k: 'talentos', n: 'Sección de creadores de contenido', sel: '[data-seccion="talentos"] .sec', texto: true },
    { k: 'nosotros', n: 'Sobre nosotros', sel: '[data-seccion="nosotros"] .sec', texto: true },
    { k: 'clientes', n: 'Clientes', sel: '[data-seccion="clientes"] .sec', texto: true },
    { k: 'contacto', n: 'Contacto', sel: '.contact', texto: true },
    { k: 'perfilTop', n: 'Perfil del creador de contenido: parte de arriba', sel: '.tp', texto: true },
    { k: 'perfilDetalle', n: 'Perfil del creador de contenido: detalles y publicaciones', sel: '[data-seccion="perfil"] section.sec', texto: true },
    { k: 'pie', n: 'Pie de página', sel: 'footer', texto: false }
  ];
  var PRESETS = [
    { n: 'Original', c: {} },
    { n: 'Neón morado', c: { '--blue': '#9b5cff', '--orange': '#ff4fd8', '--navy': '#140b2b', '--ink': '#0a0615', '--black': '#05030c' } },
    { n: 'Fuego', c: { '--blue': '#ff5a1f', '--orange': '#ffc300', '--navy': '#1f0d08', '--ink': '#120704', '--black': '#0a0402' } },
    { n: 'Esmeralda', c: { '--blue': '#12c48b', '--orange': '#f2c94c', '--navy': '#08201c', '--ink': '#04120f', '--black': '#020a08' } },
    { n: 'Rosa', c: { '--blue': '#ff3d8b', '--orange': '#ffb703', '--navy': '#220a18', '--ink': '#13050d', '--black': '#0b0207' } }
  ];
  var HEX = /^#[0-9a-fA-F]{6}$/;
  // Temporadas: solo se activan o se quitan desde este editor (los visitantes del sitio no ven ningún botón).
  var TEMPORADAS = [
    { k: 'navidad', n: 'Navidad', icono: '🎄', d: 'Guirnalda con luces en el encabezado, nieve, pinos, regalos y muñeco de nieve en el pie de página, nieve cayendo y colores verde, rojo y dorado.' },
    { k: 'halloween', n: 'Halloween', icono: '🎃', d: 'Banderines, telarañas y araña en el encabezado, cementerio, luna y calabaza en el pie de página, murciélagos volando y colores naranja, morado y negro.' }
  ];

  function temaBase() {
    var t = { colores: {}, fuentes: { titulos: 'Audiowide', texto: 'Noto Sans' }, fondos: {}, temporada: {} };
    TEMPORADAS.forEach(function (x) { t.temporada[x.k] = false; });
    COLORES.forEach(function (c) { t.colores[c.k] = c.d; });
    AREAS.forEach(function (a) { t.fondos[a.k] = { modo: 'defecto', color: '#0b1426', color2: '#2ea3f2', angulo: 180, imagen: '', oscuro: 35, texto: 'auto' }; });
    return t;
  }
  function mezclar(guardado) {
    var t = temaBase(); guardado = guardado || {};
    Object.keys(t.colores).forEach(function (k) { if (guardado.colores && HEX.test(guardado.colores[k])) t.colores[k] = guardado.colores[k]; });
    if (guardado.fuentes) { if (TITULOS.indexOf(guardado.fuentes.titulos) >= 0) t.fuentes.titulos = guardado.fuentes.titulos; if (TEXTOS.indexOf(guardado.fuentes.texto) >= 0) t.fuentes.texto = guardado.fuentes.texto; }
    Object.keys(t.fondos).forEach(function (k) { var g = guardado.fondos && guardado.fondos[k]; if (g) Object.keys(t.fondos[k]).forEach(function (c) { if (g[c] !== undefined) t.fondos[k][c] = g[c]; }); });
    if (guardado.temporada) { var activa = false; TEMPORADAS.forEach(function (x) { if (guardado.temporada[x.k] === true && !activa) { t.temporada[x.k] = true; activa = true; } }); }
    return t;
  }
  function famGoogle(n, pesos) { return n.replace(/ /g, '+') + (pesos ? ':wght@' + pesos : ''); }
  function num(v, min, max, def) { v = parseFloat(v); return isNaN(v) ? def : Math.min(max, Math.max(min, v)); }
  function nombreImagen(f) { return String(f || '').replace(/[^A-Za-z0-9._-]/g, ''); }

  // opciones.vista = true -> rutas desde la raíz del sitio (para la vista previa dentro del editor)
  function generarCss(t, opciones) {
    var vista = opciones && opciones.vista, ruta = vista ? '/config/fondos/' : 'fondos/', out = [], vars = [], bloques = [];
    var imports = [];
    if (t.fuentes.titulos !== 'Audiowide') imports.push('family=' + famGoogle(t.fuentes.titulos));
    if (t.fuentes.texto !== 'Noto Sans') imports.push('family=' + famGoogle(t.fuentes.texto, '400;500;700'));
    if (imports.length) {
      var urlFuentes = 'https://fonts.googleapis.com/css2?' + imports.join('&') + '&display=swap';
      // En el sitio las letras se cargan sin bloquear la página (assets/js/arranque.js lee --dmn-fuentes); la vista previa sí usa @import.
      out.push(vista ? '@import url("' + urlFuentes + '");' : ':root { --dmn-fuentes: "' + urlFuentes + '"; }');
    }
    out.push('/* Generado por el panel de administración (pestaña Apariencia). No hace falta editarlo a mano. */');
    COLORES.forEach(function (c) { var v = t.colores[c.k]; if (HEX.test(v) && v.toLowerCase() !== c.d) vars.push('  ' + c.k + ': ' + v + ';'); });
    if (t.fuentes.titulos !== 'Audiowide') vars.push('  --display: "' + t.fuentes.titulos + '","Arial Black",system-ui,sans-serif;');
    if (t.fuentes.texto !== 'Noto Sans') vars.push('  --body: "' + t.fuentes.texto + '",system-ui,-apple-system,"Segoe UI",sans-serif;');
    if (vars.length) out.push(':root {\n' + vars.join('\n') + '\n}');
    AREAS.forEach(function (a) {
      var f = t.fondos[a.k], reglas = [], titulos = [];
      if (!f) return;
      if (f.modo === 'color' && HEX.test(f.color)) reglas.push('background: ' + f.color + ' !important;');
      else if (f.modo === 'degradado' && HEX.test(f.color) && HEX.test(f.color2)) reglas.push('background: linear-gradient(' + Math.round(num(f.angulo, 0, 360, 180)) + 'deg, ' + f.color + ', ' + f.color2 + ') !important;');
      else if (f.modo === 'imagen' && nombreImagen(f.imagen)) {
        var o = (num(f.oscuro, 0, 90, 35) / 100).toFixed(2);
        reglas.push('background: linear-gradient(rgba(0,0,0,' + o + '), rgba(0,0,0,' + o + ')), url("' + ruta + nombreImagen(f.imagen) + '") center / cover no-repeat !important;');
      }
      if (a.texto && f.texto === 'claro') { reglas.push('color: #ffffff;'); titulos.push('#ffffff'); }
      if (a.texto && f.texto === 'oscuro') { reglas.push('color: #1a1a1a;'); titulos.push('#1a1a1a'); }
      if (reglas.length) bloques.push(a.sel + ' {\n  ' + reglas.join('\n  ') + '\n}');
      if (titulos.length) bloques.push(a.sel + ' h1, ' + a.sel + ' h2.t, ' + a.sel + ' .lead { color: ' + titulos[0] + ' !important; }');
    });
    var Temp = raiz.Temporadas || (typeof require === 'function' ? require('./temporadas.js') : {});
    TEMPORADAS.forEach(function (x) { if (t.temporada && t.temporada[x.k] === true && Temp[x.k]) bloques.push(Temp[x.k].css.trim()); });
    return out.concat(bloques).join('\n\n') + '\n';
  }

  var api = { TEMPORADAS: TEMPORADAS, COLORES: COLORES, AREAS: AREAS, TITULOS: TITULOS, TEXTOS: TEXTOS, PRESETS: PRESETS, temaBase: temaBase, mezclar: mezclar, generarCss: generarCss };
  if (typeof module !== 'undefined' && module.exports) { module.exports = api; return; }
  raiz.Apariencia = api;

  /* ------------------------- Interfaz ------------------------- */
  var D = raiz.Dreamers, tema = temaBase(), pendientes = {}, listo = false, sucio = false;
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function $(id) { return document.getElementById(id); }
  function aviso(txt, malo) { var e = $('apEstado'); if (!e) return; e.textContent = txt; e.className = malo ? 'ap-estado malo' : 'ap-estado'; clearTimeout(e._t); e._t = setTimeout(function () { e.textContent = ''; }, 6000); }

  function opcionesFuente(lista, actual) { return lista.map(function (n) { return '<option' + (n === actual ? ' selected' : '') + '>' + esc(n) + '</option>'; }).join(''); }
  function htmlFondo(a) {
    var f = tema.fondos[a.k], modos = [['defecto', 'Original'], ['color', 'Color liso'], ['degradado', 'Degradado'], ['imagen', 'Imagen']], x = '';
    x += '<select data-f="modo">' + modos.map(function (m) { return '<option value="' + m[0] + '"' + (f.modo === m[0] ? ' selected' : '') + '>' + m[1] + '</option>'; }).join('') + '</select>';
    if (f.modo === 'color' || f.modo === 'degradado') x += '<label class="ap-mini">Color <input type="color" data-f="color" value="' + esc(f.color) + '"></label>';
    if (f.modo === 'degradado') x += '<label class="ap-mini">Segundo color <input type="color" data-f="color2" value="' + esc(f.color2) + '"></label><label class="ap-mini">Ángulo <input type="range" min="0" max="360" step="15" data-f="angulo" value="' + esc(f.angulo) + '"><output>' + esc(f.angulo) + '°</output></label>';
    if (f.modo === 'imagen') {
      var src = pendientes[a.k] ? pendientes[a.k].dataUrl : (f.imagen ? '/config/fondos/' + nombreImagen(f.imagen) : '');
      x += '<label class="ap-mini">Imagen <input type="file" accept="image/*" data-f="archivo"></label>' + (src ? '<img class="ap-thumb" src="' + esc(src) + '" alt="">' : '<small>Elige una imagen.</small>') +
           '<label class="ap-mini">Oscurecer <input type="range" min="0" max="90" step="5" data-f="oscuro" value="' + esc(f.oscuro) + '"><output>' + esc(f.oscuro) + '%</output></label>';
    }
    if (a.texto) x += '<label class="ap-mini">Letras <select data-f="texto"><option value="auto"' + (f.texto === 'auto' ? ' selected' : '') + '>Automático</option><option value="claro"' + (f.texto === 'claro' ? ' selected' : '') + '>Claras</option><option value="oscuro"' + (f.texto === 'oscuro' ? ' selected' : '') + '>Oscuras</option></select></label>';
    return x;
  }

  function aplicarVista() {
    var fr = $('apVista'); if (!fr) return;
    try {
      var doc = fr.contentDocument; if (!doc || !doc.head) return;
      // la vista previa usa solo lo que ves en pantalla: se apaga el tema ya guardado de la página
      Array.prototype.forEach.call(doc.querySelectorAll('link[href*="config/tema.css"]'), function (l) { l.disabled = true; });
      var st = doc.getElementById('tema-vivo'); if (!st) { st = doc.createElement('style'); st.id = 'tema-vivo'; doc.head.appendChild(st); }
      st.textContent = generarCss(tema, { vista: true });
    } catch (_) {}
  }
  function cambio() { sucio = true; aplicarVista(); }

  function htmlTemporadas() {
    return TEMPORADAS.map(function (x) {
      var on = !!(tema.temporada && tema.temporada[x.k]);
      return '<div class="ap-temp' + (on ? ' on' : '') + '"><span class="ap-temp-ico" aria-hidden="true">' + x.icono + '</span><div class="ap-temp-info"><b>' + esc(x.n) + '</b><small>' + esc(x.d) + '</small></div>' +
        '<button type="button" class="ap-temp-btn' + (on ? ' danger' : '') + '" data-temporada="' + x.k + '" aria-pressed="' + on + '">' + (on ? 'Desactivar' : 'Activar') + '</button></div>';
    }).join('');
  }

  function pintarTodo() {
    var h = '';
    h += '<div class="ap-layout"><div class="ap-controles">';
    h += '<div class="toolbar"><div><h2>Apariencia</h2><p>Cambia colores, letras y fondos. A la derecha ves cómo queda antes de guardar.</p></div><div class="toolbar-botones"><span id="apEstado" class="ap-estado"></span><button id="apRestablecer" class="secundario">Restablecer original</button><button id="apGuardar">Guardar apariencia</button></div></div>';
    h += '<h3>Temporadas</h3><p class="ap-ayuda">Decoran el encabezado y el pie de página con efectos y colores de la fecha. Solo se activan o se quitan aquí: los visitantes no ven ningún botón. Si activas una, la otra se apaga.</p><div id="apTemporadas" class="ap-temporadas">' + htmlTemporadas() + '</div>';
    h += '<h3>Temas rápidos</h3><div class="ap-presets">' + PRESETS.map(function (p, i) { return '<button class="secundario" data-preset="' + i + '">' + esc(p.n) + '</button>'; }).join('') + '</div>';
    h += '<h3>Colores</h3><div class="ap-colores">' + COLORES.map(function (c) { return '<label class="ap-color"><span>' + esc(c.n) + (c.ayuda ? '<small>' + esc(c.ayuda) + '</small>' : '') + '</span><input type="color" data-c="' + c.k + '" value="' + esc(tema.colores[c.k]) + '"><input type="text" data-ch="' + c.k + '" value="' + esc(tema.colores[c.k]) + '" maxlength="7" spellcheck="false"></label>'; }).join('') + '</div>';
    h += '<h3>Letras</h3><div class="ap-fuentes"><label>Títulos y menú<select id="apFTitulos">' + opcionesFuente(TITULOS, tema.fuentes.titulos) + '</select></label><label>Texto<select id="apFTexto">' + opcionesFuente(TEXTOS, tema.fuentes.texto) + '</select></label></div>';
    h += '<h3>Fondos de cada parte</h3><div class="ap-fondos">' + AREAS.map(function (a) { return '<div class="ap-fondo" data-k="' + a.k + '"><b>' + esc(a.n) + '</b><div class="ap-extra">' + htmlFondo(a) + '</div></div>'; }).join('') + '</div>';
    h += '</div><aside class="ap-vista-caja"><div class="ap-vista-top"><label>Vista previa <select id="apPagina"></select></label></div><iframe id="apVista" title="Vista previa del sitio"></iframe></aside></div>';
    $('apariencia').innerHTML = h;
    var sel = $('apPagina'), paginas = [['Inicio', '/'], ['Sobre nosotros', '/nosotros/'], ['Creadores de contenido', '/creadores/'], ['Contacto', '/contacto/']];
    var primero = D && D.listaTalentos && D.listaTalentos[0]; if (primero) paginas.push(['Perfil de un creador de contenido', '/creadores/' + encodeURIComponent(primero) + '/']);
    sel.innerHTML = paginas.map(function (p) { return '<option value="' + p[1] + '">' + esc(p[0]) + '</option>'; }).join('');
    sel.onchange = function () { $('apVista').src = sel.value; };
    $('apVista').onload = aplicarVista; $('apVista').src = paginas[0][1];
  }

  function enlazar() {
    var cont = $('apariencia');
    cont.addEventListener('input', function (e) {
      var t = e.target, k, f;
      if (t.dataset.c) { tema.colores[t.dataset.c] = t.value; var tx = cont.querySelector('[data-ch="' + t.dataset.c + '"]'); if (tx) tx.value = t.value; cambio(); }
      else if (t.dataset.ch) { var v = t.value.trim(); if (v[0] !== '#') v = '#' + v; if (HEX.test(v)) { tema.colores[t.dataset.ch] = v; var pk = cont.querySelector('[data-c="' + t.dataset.ch + '"]'); if (pk) pk.value = v; cambio(); } }
      else if (t.id === 'apFTitulos') { tema.fuentes.titulos = t.value; cambio(); }
      else if (t.id === 'apFTexto') { tema.fuentes.texto = t.value; cambio(); }
      else if (t.dataset.f && (k = t.closest('.ap-fondo'))) {
        f = tema.fondos[k.dataset.k];
        if (t.dataset.f === 'archivo') return;
        f[t.dataset.f] = (t.type === 'range') ? parseFloat(t.value) : t.value;
        if (t.type === 'range' && t.nextElementSibling) t.nextElementSibling.textContent = t.value + (t.dataset.f === 'angulo' ? '°' : '%');
        cambio();
      }
    });
    cont.addEventListener('change', function (e) {
      var t = e.target, k = t.closest && t.closest('.ap-fondo');
      if (!k || !t.dataset.f) return;
      var a = AREAS.filter(function (x) { return x.k === k.dataset.k; })[0], f = tema.fondos[a.k];
      if (t.dataset.f === 'archivo') {
        var file = t.files[0]; if (!file) return;
        if (!/^image\/(png|jpeg|webp|gif|svg\+xml)$/.test(file.type)) { aviso('Usa una imagen PNG, JPG, WEBP, GIF o SVG.', true); return; }
        if (file.size > 8 * 1024 * 1024) { aviso('La imagen pesa más de 8 MB; usa una más liviana.', true); return; }
        var lector = new FileReader();
        lector.onload = function () {
          var ext = { 'image/jpeg': 'jpg', 'image/svg+xml': 'svg' }[file.type] || file.type.split('/')[1];
          pendientes[a.k] = { dataUrl: lector.result, ext: ext }; f.imagen = 'fondo-' + a.k + '.' + ext;
          k.querySelector('.ap-extra').innerHTML = htmlFondo(a); cambio();
        };
        lector.readAsDataURL(file);
      } else if (t.dataset.f === 'modo') { k.querySelector('.ap-extra').innerHTML = htmlFondo(a); cambio(); }
    });
    cont.addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      if (b.dataset.temporada) {
        var k = b.dataset.temporada, nueva = !tema.temporada[k], nombre = TEMPORADAS.filter(function (x) { return x.k === k; })[0].n;
        TEMPORADAS.forEach(function (x) { tema.temporada[x.k] = false; });
        tema.temporada[k] = nueva;
        $('apTemporadas').innerHTML = htmlTemporadas(); cambio();
        aviso(nombre + (nueva ? ' activada en la vista previa.' : ' desactivada en la vista previa.') + ' Pulsa "Guardar apariencia" para aplicarlo al sitio.');
      } else if (b.dataset.preset !== undefined) {
        var p = PRESETS[+b.dataset.preset]; COLORES.forEach(function (c) { tema.colores[c.k] = p.c[c.k] || c.d; });
        cont.querySelectorAll('[data-c]').forEach(function (i) { i.value = tema.colores[i.dataset.c]; });
        cont.querySelectorAll('[data-ch]').forEach(function (i) { i.value = tema.colores[i.dataset.ch]; }); cambio();
      } else if (b.id === 'apRestablecer') {
        if (!confirm('¿Volver a los colores, letras y fondos originales y apagar las temporadas? Se aplica al pulsar "Guardar apariencia".')) return;
        tema = temaBase(); pendientes = {}; pintarTodo(); cambio();
      } else if (b.id === 'apGuardar') guardar();
    });
  }

  async function guardar() {
    var imagenes = {}; Object.keys(pendientes).forEach(function (k) { if (tema.fondos[k].modo === 'imagen') imagenes[k] = pendientes[k].dataUrl; });
    var btn = $('apGuardar'); btn.disabled = true;
    try {
      var r = await fetch('/api/tema', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ tema: tema, css: generarCss(tema), imagenes: imagenes }) });
      var d = await r.json(); if (!d.ok) throw new Error(d.error || 'No se pudo guardar.');
      pendientes = {}; sucio = false; aviso('Apariencia guardada en config/tema.css.');
    } catch (e) { aviso('No se pudo guardar. Abre el editor con servidor_editor.py. ' + (e.message || ''), true); }
    btn.disabled = false;
  }

  async function iniciar() {
    if (listo) return; listo = true;
    try { var r = await fetch('/config/tema.json?v=' + Date.now()); if (r.ok) tema = mezclar(await r.json()); } catch (_) {}
    pintarTodo(); enlazar();
  }
  document.addEventListener('click', function (e) { var b = e.target.closest && e.target.closest('[data-tab="apariencia"]'); if (b) iniciar(); });
})(typeof window !== 'undefined' ? window : globalThis);
