/* Revisión de ortografía del editor. Envía los textos al servidor local (/api/ortografia), que consulta LanguageTool. */
(function(){
  'use strict';
  var TECNICOS=/^(_estilos|pagina|despuesde|alineacion|tamano|ancho|fondo|colorfondo|colortitulo|colortexto|visible|destino|imagen|foto|logo|enlace|url|correo|correodestino|email|carpeta|plataforma|usuario|seguidores|valor|color|posicionfoto|fotozoom|_origen|submenu|id|clave|sufijotitulo|frames|redes|nombre)$/i;
  function esTexto(s){return typeof s==='string'&&/[A-Za-zÁÉÍÓÚáéíóúñÑ]{3,}/.test(s)&&!/^(https?:\/\/|[\w.\/-]+\.(png|jpe?g|svg|webp|gif)$)/i.test(s.trim());}
  function recorrer(nodo,ruta,raiz,etq,salida){
    if(Array.isArray(nodo)){nodo.forEach(function(v,i){recorrer(v,ruta.concat(i),raiz,etq,salida);});}
    else if(nodo&&typeof nodo==='object'){Object.keys(nodo).forEach(function(k){if(TECNICOS.test(k))return;recorrer(nodo[k],ruta.concat(k),raiz,etq,salida);});}
    else if(esTexto(nodo)){salida.push({raiz:raiz,ruta:ruta,texto:nodo,etiqueta:etq+' · '+ruta.join(' › ')});}
  }
  function reunir(){
    var E=window.DreamersEditor,salida=[];
    E.talentos().forEach(function(t,i){recorrer(t,[],{tipo:'t',i:i},'Creador '+(t.nombre||t.carpeta),salida);});
    var c=E.contenidos();Object.keys(c).forEach(function(k){recorrer(c[k],[],{tipo:'c',k:k},'Sección '+k,salida);});
    return salida;
  }
  function destino(el){var E=window.DreamersEditor,o=el.raiz.tipo==='t'?E.talentos()[el.raiz.i]:E.contenidos()[el.raiz.k];return o;}
  function leer(el){var o=destino(el);try{el.ruta.forEach(function(p){o=o[p];});return o;}catch(e){return undefined;}}
  function escribir(el,v){var o=destino(el);for(var i=0;i<el.ruta.length-1;i++)o=o[el.ruta[i]];o[el.ruta[el.ruta.length-1]]=v;}
  function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}

  var caja;
  function ventana(){
    if(caja)return caja;
    caja=document.createElement('div');caja.className='modal';caja.hidden=true;
    caja.innerHTML='<div class="modal-box"><div class="modal-head"><h2>Revisión de ortografía</h2><button class="ghost" data-o="cerrar">✕</button></div><div id="ortoCuerpo"></div></div>';
    document.body.appendChild(caja);
    caja.addEventListener('click',function(e){var b=e.target.closest('[data-o]');if(b&&b.dataset.o==='cerrar')caja.hidden=true;});
    return caja;
  }
  function cuerpo(){return document.getElementById('ortoCuerpo');}

  async function revisar(){
    var lista=reunir(),m=ventana();m.hidden=false;
    cuerpo().innerHTML='<p>Revisando '+lista.length+' textos… puede tardar unos segundos.</p>';
    var datos;
    try{
      var r=await fetch('/api/ortografia',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({textos:lista.map(function(x){return x.texto;})})});
      datos=await r.json();
    }catch(e){cuerpo().innerHTML='<p class="error">Abre el editor con servidor_editor.py para usar el corrector.</p>';return;}
    if(!datos.ok){cuerpo().innerHTML='<p class="error">'+esc(datos.error||'No se pudo revisar.')+'</p>';return;}
    var casos=[];
    lista.forEach(function(el,i){(datos.problemas[i]||[]).forEach(function(p){casos.push({el:el,p:p});});});
    mostrar(casos,lista.length);
  }

  function mostrar(casos,total){
    var c=cuerpo();
    if(!casos.length){c.innerHTML='<p>✓ Revisados '+total+' textos. No se encontraron faltas.</p>';return;}
    var html='<p>Se encontraron <b>'+casos.length+'</b> posibles faltas en '+total+' textos. Revisa cada una: nombres propios y marcas pueden marcarse como correctas con «Ignorar siempre».</p>'+
      '<div class="modal-actions" style="justify-content:flex-start;margin:0 0 12px"><button data-o="todo">Corregir todo con la 1.ª sugerencia</button></div><div id="ortoLista">';
    casos.forEach(function(k,i){
      var t=k.el.texto,p=k.p;
      html+='<div class="orto-caso" data-i="'+i+'" style="border:1px solid #263650;border-radius:10px;padding:12px;margin-bottom:10px">'+
        '<div style="color:#8f9db6;font-size:12px">'+esc(k.el.etiqueta)+'</div>'+
        '<div style="margin:6px 0">'+esc(t.slice(Math.max(0,p.inicio-30),p.inicio))+'<mark style="background:#a83a43;color:#fff;padding:0 3px;border-radius:3px">'+esc(p.palabra)+'</mark>'+esc(t.slice(p.inicio+p.largo,p.inicio+p.largo+30))+'</div>'+
        '<div style="font-size:13px;color:#b9c6dc;margin-bottom:8px">'+esc(p.mensaje)+'</div><div style="display:flex;gap:6px;flex-wrap:wrap">'+
        p.reemplazos.map(function(r,j){return '<button data-o="aplicar" data-j="'+j+'">'+esc(r)+'</button>';}).join('')+
        '<button class="secundario" data-o="ignorar">Ignorar</button><button class="ghost" data-o="siempre">Ignorar siempre</button></div></div>';
    });
    c.innerHTML=html+'</div>';
    c._casos=casos;
    c.onclick=async function(e){
      var b=e.target.closest('[data-o]');if(!b||b.dataset.o==='cerrar')return;
      var o=b.dataset.o;
      if(o==='todo'){
        // De atrás hacia adelante dentro de cada texto, para que las posiciones no se muevan.
        var orden=casos.map(function(k,i){return i;}).sort(function(a,b){return casos[b].p.inicio-casos[a].p.inicio;});
        orden.forEach(function(i){if(!casos[i].hecho)aplicar(casos[i],0);});
        await terminar(c);return;
      }
      var cont=b.closest('.orto-caso'),k=casos[+cont.dataset.i];
      if(o==='aplicar'){aplicar(k,+b.dataset.j);await guardarCambios();cont.remove();}
      else if(o==='ignorar'){cont.remove();}
      else if(o==='siempre'){
        try{await fetch('/api/ortografia/ignorar',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({palabra:k.p.palabra})});}catch(x){}
        c.querySelectorAll('.orto-caso').forEach(function(n){if(casos[+n.dataset.i].p.palabra.toLowerCase()===k.p.palabra.toLowerCase())n.remove();});
      }
      if(!c.querySelector('.orto-caso'))c.innerHTML='<p>✓ Revisión terminada.</p>';
    };
  }
  function aplicar(k,j){
    var actual=leer(k.el);if(typeof actual!=='string')return;
    // Si el texto cambió desde que se revisó (otra corrección), se busca la palabra de nuevo.
    var pal=k.p.palabra,nuevo=k.p.reemplazos[j],pos=actual.substr(k.p.inicio,k.p.largo)===pal?k.p.inicio:actual.indexOf(pal);
    if(pos<0)return;
    escribir(k.el,actual.slice(0,pos)+nuevo+actual.slice(pos+pal.length));k.hecho=true;
    k.el.texto=leer(k.el);
  }
  async function guardarCambios(){await window.DreamersEditor.guardar();window.DreamersEditor.pintar();}
  async function terminar(c){await guardarCambios();c.innerHTML='<p>✓ Correcciones aplicadas y guardadas. Vuelve a pulsar «Revisar ortografía» para comprobar.</p>';}

  // Subrayado del navegador (en español) en los campos de texto del editor.
  new MutationObserver(function(){document.querySelectorAll('.modal input[type=text],.modal input:not([type]),.modal textarea').forEach(function(x){x.setAttribute('spellcheck','true');x.setAttribute('lang','es');});})
    .observe(document.body,{childList:true,subtree:true});

  document.addEventListener('click',function(e){if(e.target.id==='revisarOrtografia')revisar();});
})();
