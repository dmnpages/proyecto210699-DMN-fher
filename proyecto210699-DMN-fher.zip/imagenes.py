"""Velocidad: fotos ligeras y un solo archivo con los datos de todos los creadores.

- optimizar(bytes, max_lado): reduce y convierte a WebP (si Pillow está instalado: pip install pillow).
- optimizar_carpetas(): recorre creadores/*/foto-admin.* y las deja ligeras (actualiza datos.js).
- escribir_paquete(): crea creadores/todos.js (la página lo carga en 1 petición en lugar de 20+).
Uso manual:  python imagenes.py
"""
import io, json, re, sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
MAX_FOTO = 1000


def extension_de(datos):
    if datos[:3] == b"\xff\xd8\xff":
        return "jpg"
    if datos[:8] == b"\x89PNG\r\n\x1a\n":
        return "png"
    if datos[:4] == b"RIFF" and datos[8:12] == b"WEBP":
        return "webp"
    if datos[:4] == b"GIF8":
        return "gif"
    if datos.lstrip()[:5] in (b"<svg ", b"<?xml") or b"<svg" in datos[:400]:
        return "svg"
    return None


def optimizar(datos, max_lado=MAX_FOTO, calidad=82):
    """Devuelve (bytes, extension). Si no se puede mejorar, devuelve los originales."""
    ext = extension_de(datos)
    if ext in (None, "gif", "svg"):
        return datos, ext
    try:
        from PIL import Image, ImageOps
    except Exception:
        return datos, ext
    try:
        im = Image.open(io.BytesIO(datos))
        im = ImageOps.exif_transpose(im)
        if max(im.size) > max_lado:
            im.thumbnail((max_lado, max_lado), Image.LANCZOS)
        if im.mode not in ("RGB", "RGBA"):
            im = im.convert("RGBA" if "A" in im.getbands() or im.mode == "P" else "RGB")
        salida = io.BytesIO()
        im.save(salida, "WEBP", quality=calidad, method=6)
        nuevo = salida.getvalue()
        return (nuevo, "webp") if len(nuevo) < len(datos) else (datos, ext)
    except Exception:
        return datos, ext


def optimizar_carpetas():
    hechos = []
    for d in sorted((RAIZ / "creadores").iterdir()):
        datos_js = d / "datos.js"
        if not d.is_dir() or not datos_js.exists():
            continue
        texto = datos_js.read_text(encoding="utf-8")
        m = re.search(r'"foto":\s*"([^"]*)"', texto)
        if not m:
            continue
        valor = m.group(1)
        if valor.startswith("data:"):
            import base64
            crudo = base64.b64decode(valor.split(",", 1)[1])
            origen = None
        else:
            origen = d / valor
            if not origen.is_file():
                continue
            crudo = origen.read_bytes()
        nuevo, ext = optimizar(crudo)
        if ext is None or (origen is not None and nuevo is crudo):
            continue
        for vieja in d.glob("foto-admin.*"):
            vieja.unlink()
        (d / ("foto-admin." + ext)).write_bytes(nuevo)
        texto = texto[:m.start(1)] + "foto-admin." + ext + texto[m.end(1):]
        datos_js.write_text(texto, encoding="utf-8")
        hechos.append((d.name, len(crudo) // 1024, len(nuevo) // 1024))
    return hechos


def escribir_paquete():
    """creadores/todos.js: los datos.js de todos los creadores, en el orden de lista.js."""
    lista = re.findall(r'"([^"]+)"', (RAIZ / "creadores" / "lista.js").read_text(encoding="utf-8"))
    partes = []
    for carpeta in lista:
        f = RAIZ / "creadores" / carpeta / "datos.js"
        if f.exists():
            partes.append("Dreamers._actual=%s;\n%s" % (json.dumps(carpeta), f.read_text(encoding="utf-8").strip()))
    (RAIZ / "creadores" / "todos.js").write_text("\n".join(partes) + "\n", encoding="utf-8")
    return len(partes)


if __name__ == "__main__":
    for nombre, antes, despues in optimizar_carpetas():
        print("%-22s %6d KB -> %5d KB" % (nombre, antes, despues))
    print("Paquete con %d creadores." % escribir_paquete())
