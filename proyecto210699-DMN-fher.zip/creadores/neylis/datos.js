Dreamers.talento({
  "nombre": "Neylis",
  "ciudad": "Matagalpa",
  "seguidores": "2.6K",
  "descripcion": "Cosplayer y creadora de contenido enfocada en el entorno de la cultura pop asiática, el anime y videojuegos.",
  "foto": "foto-admin.webp",
  "posicionFoto": "50% 50%",
  "fotoZoom": 1,
  "categorias": [
    "Cosplayer"
  ],
  "redes": [
    {
      "plataforma": "Instagram",
      "enlace": "https://www.instagram.com/_neylis_/",
      "seguidores": "1.4K"
    },
    {
      "plataforma": "Tiktok",
      "enlace": "https://www.tiktok.com/@_neylis_0/",
      "seguidores": "1.2K"
    }
  ],
  "formatos": [
    "Cosplayer",
    "Lifestyle"
  ],
  "ideal": [
    "Eventos",
    "Cosméticos",
    "Gaming"
  ],
  "dato": {
    "valor": "49K",
    "texto": "Likes totales en TikTok"
  },
  "frames": []
});
