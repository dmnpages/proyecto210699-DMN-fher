Dreamers.talento({
  "nombre": "Daneska Solorsano",
  "ciudad": "Diriamba",
  "seguidores": "3.4K",
  "descripcion": "",
  "foto": "foto-admin.webp",
  "posicionFoto": "50% 50%",
  "fotoZoom": 1,
  "categorias": [
    "Streamer"
  ],
  "redes": [
    {
      "plataforma": "Instagram",
      "enlace": "https://www.instagram.com/daneska_solorzano/",
      "seguidores": "715"
    },
    {
      "plataforma": "Tiktok",
      "enlace": "https://www.tiktok.com/@daneska_solorzano/",
      "seguidores": "2.7K"
    }
  ],
  "formatos": [
    "Trends",
    "Streams",
    "Dance"
  ],
  "ideal": [
    "Marketing",
    "Dance",
    "Event Host"
  ],
  "dato": {
    "valor": "29.7K",
    "texto": "Likes totales en TikTok"
  },
  "frames": []
});
