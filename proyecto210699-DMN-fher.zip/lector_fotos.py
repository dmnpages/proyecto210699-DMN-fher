"""Busca la foto de perfil de un creador en sus redes y la guarda en su carpeta (creadores/<carpeta>/foto-redes.<ext>).

Se usa solo cuando el creador no tiene foto. La imagen se DESCARGA al proyecto (no se enlaza), porque los enlaces de las redes caducan.
Es la imagen pública de su perfil: úsala solo con permiso del creador. Suele ser pequeña (cuadrada); una foto propia siempre se ve mejor.
"""
import ipaddress, json, re, socket, urllib.error, urllib.parse, urllib.request
import lector_seguidores as L

ORDEN = ["instagram", "tiktok", "youtube", "twitch", "facebook", "x", "kick"]
MAX_BYTES = 6_000_000
MIN_BYTES = 4_000


def _publica(url):
    """Solo https y solo hacia direcciones de internet (nunca a la red local)."""
    p = urllib.parse.urlparse(url)
    if p.scheme != "https" or not p.hostname:
        return False
    try:
        return all(ipaddress.ip_address(i[4][0]).is_global for i in socket.getaddrinfo(p.hostname, 443, proto=socket.IPPROTO_TCP))
    except Exception:
        return False


class _SinRedireccion(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


def _abrir(url, limite):
    """Descarga siguiendo hasta 3 redirecciones, validando cada destino."""
    opener = urllib.request.build_opener(_SinRedireccion)
    for _ in range(4):
        if not _publica(url):
            raise ValueError("destino no permitido")
        try:
            with opener.open(urllib.request.Request(url, headers={"User-Agent": L.NAVEGADOR, "Accept": "*/*"}), timeout=15) as r:
                return r.read(limite + 1)
        except urllib.error.HTTPError as e:
            destino = e.headers.get("Location") if e.code in (301, 302, 303, 307, 308) else None
            if not destino:
                raise
            url = urllib.parse.urljoin(url, destino)
    raise ValueError("demasiadas redirecciones")


def extension(datos):
    if datos[:3] == b"\xff\xd8\xff":
        return "jpg"
    if datos[:8] == b"\x89PNG\r\n\x1a\n":
        return "png"
    if datos[:4] == b"RIFF" and datos[8:12] == b"WEBP":
        return "webp"
    return None


def imagen_en(html):
    """Saca la URL de la foto de perfil del código de una página."""
    html = (html or "").replace("\\u002F", "/").replace("\\/", "/").replace("&amp;", "&")
    for patron in (r'"avatarLarger":"(https:[^"]+)"', r'<meta[^>]+property=["\']og:image["\'][^>]+content=["\']([^"\']+)',
                   r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:image["\']',
                   r'<meta[^>]+name=["\']twitter:image["\'][^>]+content=["\']([^"\']+)'):
        m = re.search(patron, html)
        if m and m.group(1).startswith("https://"):
            return m.group(1)
    return None


def buscar(redes, metas=None):
    """Devuelve (bytes, extension, red) de la primera foto válida, o None. metas: {enlace: url de imagen} leído con el navegador."""
    metas = metas or {}
    validas = []
    for r in redes:
        enlace = str(r.get("enlace", "")).strip()
        red = L.plataforma_de(r.get("plataforma", ""), enlace)
        host = urllib.parse.urlparse(enlace).hostname or ""
        if enlace and red in L.DOMINIOS and any(host == d or host.endswith("." + d) for d in L.DOMINIOS[red]):
            validas.append((ORDEN.index(red) if red in ORDEN else 99, red, enlace))
    for _, red, enlace in sorted(validas):
        urls = []
        if metas.get(enlace):
            urls.append(metas[enlace])
        try:
            u = imagen_en(L.descargar(enlace))
            if u and u not in urls:
                urls.append(u)
        except Exception:
            pass
        for u in urls:
            try:
                datos = _abrir(u, MAX_BYTES)
            except Exception:
                continue
            ext = extension(datos)
            if ext and MIN_BYTES < len(datos) <= MAX_BYTES:
                return datos, ext, red
    return None
