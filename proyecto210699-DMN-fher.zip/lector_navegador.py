"""Lector de seguidores con un navegador propio donde TÚ inicias sesión una sola vez.

  python lector_navegador.py conectar   -> abre una ventana de Chromium; entra a tus redes y ciérrala.
  python lector_navegador.py leer       -> (lo usa servidor_editor.py) lee los perfiles con la sesión guardada.

La sesión queda en admin/sesiones/ (carpeta que NO se sube a GitHub). No toca tu Chrome normal ni lee sus cookies.
Requiere:  pip install playwright   y luego   playwright install chromium
"""
import asyncio, json, re, sys, time
from pathlib import Path
import lector_seguidores as L

RAIZ = Path(__file__).resolve().parent
PERFIL = RAIZ / "admin" / "sesiones"
LOGINS = ["https://www.instagram.com/accounts/login/", "https://www.tiktok.com/login", "https://www.twitch.tv/login",
          "https://accounts.google.com/", "https://www.facebook.com/login/", "https://x.com/i/flow/login"]
AVISO = "Falta Playwright. Instálalo una vez con:  pip install playwright   y   playwright install chromium"


def disponible():
    import importlib.util
    return importlib.util.find_spec("playwright") is not None


def hay_sesion():
    return PERFIL.exists() and any(PERFIL.iterdir())


def numero_en_texto(texto):
    """Busca 'N followers / seguidores / subscribers' en el texto visible (sin mezclar números vecinos)."""
    return L.antes_de(r"followers?|seguidores|subscribers?|suscriptores", texto)


def extraer(red, html, texto):
    n = None
    if red == "youtube":
        n = L.leer_youtube(html)
    elif red == "tiktok":
        n = L.leer_tiktok(html)
    return n or L.leer_og(html) or numero_en_texto(texto)


async def leer_pagina(context, plataforma, enlace):
    """Abre el perfil y devuelve el número en cuanto aparece (sin esperas fijas)."""
    red = L.plataforma_de(plataforma, enlace)
    page = await context.new_page()
    try:
        await page.goto(enlace, wait_until="domcontentloaded", timeout=25000)
        limite = time.time() + 9
        while True:
            try:
                html = await page.content()
                texto = await page.evaluate("document.body ? document.body.innerText : ''")
                n = extraer(red, html, texto)
            except Exception:
                n = None
            if n or time.time() > limite:
                return n, (L.leer_likes_tiktok(html) if red == "tiktok" and n else None)
            await page.wait_for_timeout(400)
    finally:
        await page.close()


async def leer_lote(context, redes, simultaneas=6):
    """Lee varias redes a la vez (solo texto: se bloquean imágenes, videos y fuentes para ir más rápido)."""
    cupo = asyncio.Semaphore(simultaneas)

    async def uno(r):
        enlace, plataforma = str(r.get("enlace", "")), str(r.get("plataforma", ""))
        host = L.urllib.parse.urlparse(enlace).hostname or ""
        red = L.plataforma_de(plataforma, enlace)
        if red not in L.DOMINIOS or not any(host == d or host.endswith("." + d) for d in L.DOMINIOS[red]):
            return {"id": r.get("id"), "ok": False, "error": "El enlace no corresponde a una red conocida."}
        async with cupo:
            try:
                n, likes = await leer_pagina(context, plataforma, enlace)
            except Exception as e:
                return {"id": r.get("id"), "ok": False, "error": "No se pudo abrir la página (%s)." % (str(e).split("\n")[0][:80])}
        if n:
            return {"id": r.get("id"), "ok": True, "seguidores": n, "likes": likes}
        return {"id": r.get("id"), "ok": False, "error": "No se encontró el número (¿la sesión venció o la página cambió?)."}

    return await asyncio.gather(*[uno(r) for r in redes])


async def solo_texto(route):
    if route.request.resource_type in ("image", "media", "font"):
        await route.abort()
    else:
        await route.continue_()


def abrir(playwright, visible):
    PERFIL.mkdir(parents=True, exist_ok=True)
    return playwright.chromium.launch_persistent_context(
        str(PERFIL), headless=not visible, viewport={"width": 1200, "height": 850}, locale="es-ES",
        args=["--disable-blink-features=AutomationControlled"])


def conectar():
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        ctx = abrir(p, True)
        for i, url in enumerate(LOGINS):
            pag = ctx.pages[0] if i == 0 and ctx.pages else ctx.new_page()
            try:
                pag.goto(url, timeout=20000)
            except Exception:
                pass
        print("Inicia sesión en las redes que uses y cierra la ventana cuando termines.", flush=True)
        try:
            while ctx.pages:
                time.sleep(1)
        except Exception:
            pass
        try:
            ctx.close()
        except Exception:
            pass


def leer():
    from playwright.async_api import async_playwright
    redes = json.loads(sys.stdin.read() or "[]")

    async def principal():
        async with async_playwright() as p:
            PERFIL.mkdir(parents=True, exist_ok=True)
            ctx = await p.chromium.launch_persistent_context(
                str(PERFIL), headless=True, viewport={"width": 1200, "height": 850}, locale="es-ES",
                args=["--disable-blink-features=AutomationControlled"])
            try:
                await ctx.route("**/*", solo_texto)
                return await leer_lote(ctx, redes)
            finally:
                await ctx.close()

    print(json.dumps(asyncio.run(principal()), ensure_ascii=False))


async def cosechar_pagina(context, enlace):
    """Abre un perfil, baja un poco y devuelve todos los enlaces de la página (para encontrar publicaciones)."""
    page = await context.new_page()
    try:
        await page.goto(enlace, wait_until="domcontentloaded", timeout=25000)
        await page.wait_for_timeout(2500)
        for _ in range(3):
            await page.mouse.wheel(0, 1600)
            await page.wait_for_timeout(900)
        return "\n".join(await page.eval_on_selector_all("a[href]", "els => els.map(e => e.href)"))
    finally:
        await page.close()


def cosechar():
    """Entrada (stdin): lista de enlaces de perfil. Salida: {enlace: enlaces encontrados}."""
    from playwright.async_api import async_playwright
    enlaces = json.loads(sys.stdin.read() or "[]")

    async def principal():
        async with async_playwright() as p:
            PERFIL.mkdir(parents=True, exist_ok=True)
            ctx = await p.chromium.launch_persistent_context(
                str(PERFIL), headless=True, viewport={"width": 1200, "height": 850}, locale="es-ES",
                args=["--disable-blink-features=AutomationControlled"])
            try:
                await ctx.route("**/*", solo_texto)
                cupo = asyncio.Semaphore(4)

                async def uno(e):
                    async with cupo:
                        try:
                            return e, await cosechar_pagina(ctx, e)
                        except Exception:
                            return e, ""
                return dict(await asyncio.gather(*[uno(e) for e in enlaces]))
            finally:
                await ctx.close()

    print(json.dumps(asyncio.run(principal()), ensure_ascii=False))


async def meta_pagina(context, enlace):
    """Abre un perfil y devuelve la imagen principal (og:image) que ve tu sesión."""
    page = await context.new_page()
    try:
        await page.goto(enlace, wait_until="domcontentloaded", timeout=25000)
        await page.wait_for_timeout(2000)
        return await page.evaluate("""() => {
            const m = document.querySelector('meta[property="og:image"],meta[name="twitter:image"]');
            if (m && m.content) return m.content;
            const i = document.querySelector('img[alt*="perfil"],img[alt*="profile"]');
            return i ? i.src : '';
        }""")
    finally:
        await page.close()


def metas():
    """Entrada (stdin): lista de enlaces de perfil. Salida: {enlace: url de la imagen de perfil}."""
    from playwright.async_api import async_playwright
    enlaces = json.loads(sys.stdin.read() or "[]")

    async def principal():
        async with async_playwright() as p:
            PERFIL.mkdir(parents=True, exist_ok=True)
            ctx = await p.chromium.launch_persistent_context(
                str(PERFIL), headless=True, viewport={"width": 1200, "height": 850}, locale="es-ES",
                args=["--disable-blink-features=AutomationControlled"])
            try:
                await ctx.route("**/*", solo_texto)
                cupo = asyncio.Semaphore(4)

                async def uno(e):
                    async with cupo:
                        try:
                            return e, await meta_pagina(ctx, e)
                        except Exception:
                            return e, ""
                return dict(await asyncio.gather(*[uno(e) for e in enlaces]))
            finally:
                await ctx.close()

    print(json.dumps(asyncio.run(principal()), ensure_ascii=False))


if __name__ == "__main__":
    if not disponible():
        print(AVISO, file=sys.stderr)
        sys.exit(2)
    {"conectar": conectar, "leer": leer, "cosechar": cosechar, "metas": metas}.get(sys.argv[1] if len(sys.argv) > 1 else "", lambda: print(__doc__))()
